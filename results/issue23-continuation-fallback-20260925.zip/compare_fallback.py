"""Paired saved-measurement comparison; executes the existing production fallback."""
import gzip
import hashlib
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
from tunnel_guard.geometry import TrackGeometry

root = Path('build/issue23-continuation-holdout')
plan = json.loads((root/'fallback-plan.json').read_text())
if hashlib.sha256(Path(plan['input']).read_bytes()).hexdigest()!=plan['input_sha256']:
    raise ValueError('Frozen holdout observations changed')
config_path = Path(plan['config'])
source = Path('tunnel_guard/geometry.py')
if hashlib.sha256(config_path.read_bytes()).hexdigest()!=plan['config_sha256'] or hashlib.sha256(source.read_bytes()).hexdigest()!=plan['geometry_sha256']:
    raise ValueError('Frozen estimator changed')
state = TrackGeometry.__new__(TrackGeometry)
state.config = json.loads(config_path.read_text())
groups = defaultdict(list)
with gzip.open(plan['input'],'rt') as stream, gzip.open(root/'fallback-pairs.jsonl.gz','wt') as journal:
    for line in stream:
        item = json.loads(line)
        anchors = np.asarray(item['retained_anchors'], dtype=float)
        # Exact existing edge fallback uses the last two training anchors.
        state.rail_anchors = anchors[-3:-1]
        center, _, uncertainty = state.path(np.array([anchors[-1,0]]))
        signed_error = float(center[0]-anchors[-1,1])
        pair = {'recording':item['recording'],'frame':item['frame'],
                'role':item['role'],'negative_alarm':item['negative_alarm'],
                'training_selected_anchors':item['training_selected_anchors'],
                'original_signed_discrepancy_m':item['signed_discrepancy_m'],
                'fallback_signed_discrepancy_m':signed_error,
                'original_uncertainty_m':item['prediction_heuristic_uncertainty_m'],
                'fallback_uncertainty_m':float(uncertainty[0]) if np.isfinite(uncertainty[0]) else None}
        journal.write(json.dumps(pair,allow_nan=False)+'\n')
        for key in ['all','selected:'+str(pair['training_selected_anchors']), 'recording:'+pair['recording']]:
            groups[key].append(pair)
        if pair['negative_alarm'] and pair['training_selected_anchors']==3:
            groups['negative_alarm_selected_three'].append(pair)
summary = {}
for key, rows in groups.items():
    original = np.abs([r['original_signed_discrepancy_m'] for r in rows])
    fallback = np.abs([r['fallback_signed_discrepancy_m'] for r in rows])
    summary[key] = {'paired_holdouts':len(rows),'fallback_lower_error':int((fallback<original).sum()),
        'fallback_higher_error':int((fallback>original).sum()),'equal_error':int((fallback==original).sum()),
        'original_absolute_error_quantiles_m':list(map(float,np.quantile(original,[.5,.9,.99,1]))),
        'fallback_absolute_error_quantiles_m':list(map(float,np.quantile(fallback,[.5,.9,.99,1]))),
        'original_mean_absolute_error_m':float(original.mean()),'fallback_mean_absolute_error_m':float(fallback.mean())}
report={'groups':summary,'quantile_order':['median','p90','p99','max'],
        'decision':'No detector change or promotion. This paired internal measurement comparison is not physical ground truth or fixed-panel acceptance.',
        'limits':plan['limits']}
(root/'fallback-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
