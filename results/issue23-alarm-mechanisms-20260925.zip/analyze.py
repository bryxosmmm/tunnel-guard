import collections
import gzip
import hashlib
import json
from pathlib import Path

root = Path('build/autoresearch-issue23/run-0002')
out = Path('build/issue23-alarm-mechanisms')
reference = json.loads((root / 'recordings.json').read_text())
config = json.loads((root / 'detector.json').read_text())
max_gap = round(config['frame_max_gap_s'] * 1e9)
counts = collections.Counter()
mechanisms = collections.Counter()
relations = collections.Counter()
recordings = {}
evidence = []
for name, expected in reference.items():
    if expected['role'] not in ('organizer_declared_empty', 'continuous_negative'):
        continue
    local = collections.Counter()
    prior = None
    path = root / (name + '.jsonl.gz')
    digest = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
    with gzip.open(path, 'rt') as stream:
        for line in stream:
            row = json.loads(line)
            local['frames'] += 1
            alarm = row['status'] == 'obstacle'
            stamp = row['measurement_timestamp_ns']
            if prior and stamp <= prior[0]:
                raise ValueError('Non-increasing acquisition timestamp')
            start = alarm and (prior is None or not prior[1] or stamp-prior[0] > max_gap)
            prior = stamp, alarm
            if not alarm:
                continue
            local['alarm_frames'] += 1
            local['alarm_episodes'] += int(start)
            objects = [o for o in row['objects'] if o['path_relation'] in ('intersecting', 'unresolved')
                       and o['confirmed'] and o['intersection_confirmed']]
            if not objects:
                raise ValueError('Alarm without confirmed intersection')
            anchors = row['geometry']['rail_anchors']
            last_anchor = max((a[0] for a in anchors), default=None)
            local['alarm_components'] += len(objects)
            local['all_components_shared_structure_frames'] += int(all(o['certified_unexplained_voxels'] == 0 for o in objects))
            local['all_components_after_last_anchor_frames'] += int(last_anchor is not None and all(o['bbox_min'][0] > last_anchor for o in objects))
            local['motion_invalid_alarm_frames'] += int(not row['motion']['valid'])
            for obj in objects:
                mechanisms[obj['intersection_confirmation']] += 1
                relations[obj['path_relation_reason']] += 1
                local['components_without_unexplained_certified_support'] += int(obj['certified_unexplained_voxels'] == 0)
                local['components_wholly_after_last_anchor'] += int(last_anchor is not None and obj['bbox_min'][0] > last_anchor)
            evidence.append({'recording': name, 'frame': row['frame'], 'measurement_timestamp_ns': stamp,
                             'episode_start': bool(start), 'last_rail_anchor_m': last_anchor,
                             'supported_range_m': row.get('supported_range_m'), 'motion': row['motion'],
                             'geometry': row['geometry'], 'objects': objects})
    for key in ('frames', 'alarm_frames', 'alarm_episodes'):
        if local[key] != expected[key]:
            raise ValueError((name, key, local[key], expected[key]))
    recordings[name] = {'counts': dict(local), 'input_sha256': digest, 'input': str(path)}
    counts.update(local)
report = {'source_run': str(root), 'config_sha256': hashlib.sha256((root/'detector.json').read_bytes()).hexdigest(),
          'method': 'Read-only accounting of complete saved actual replay; no new detector run or counterfactual suppression.',
          'valid': counts['frames'] == 13558 and counts['alarm_frames'] == 134 and counts['alarm_episodes'] == 113,
          'counts': dict(counts), 'component_confirmation_mechanisms': dict(mechanisms),
          'component_relation_reasons': dict(relations), 'recordings': recordings,
          'limitations': ['Components and frames are not independent physical events.',
                         'Extrapolation is not proof of wrong geometry.',
                         'Shared structural support is ambiguity, not proof of infrastructure; suppressing it may erase real obstacles.',
                         'No threshold, production source or configuration changed.']}
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
with gzip.open(out/'alarm-evidence.jsonl.gz', 'wt') as stream:
    for entry in evidence:
        stream.write(json.dumps(entry)+'\n')
print(json.dumps(report, indent=2))
if not report['valid']:
    raise ValueError('Canonical totals mismatch')
