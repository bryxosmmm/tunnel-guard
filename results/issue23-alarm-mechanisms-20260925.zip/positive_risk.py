import collections
import hashlib
import json
from pathlib import Path
root = Path('build/autoresearch-issue23/run-0002')
report = {'method': 'Read-only description of frozen majority-original-return synthetic attribution and authored person correspondence; no detector modification or suppression applied.', 'synthetic': {}, 'inputs': {}}
for name in ['synthetic.json', 'person.json']:
    report['inputs'][name] = hashlib.sha256((root/name).read_bytes()).hexdigest()
for event, rows in json.loads((root/'synthetic.json').read_text()).items():
    counts = collections.Counter()
    shared_frames = []
    for row in rows:
        confirmed = [o for o in row['components'] if o['intersection_confirmed']]
        if not confirmed:
            continue
        counts['intersection_confirmed_frames'] += 1
        counts['intersection_confirmed_components'] += len(confirmed)
        counts['shared_structure_components'] += sum(o['certified_unexplained_voxels'] == 0 for o in confirmed)
        if all(o['certified_unexplained_voxels'] == 0 for o in confirmed):
            shared_frames.append(row['frame'])
    report['synthetic'][event] = {'counts': dict(counts), 'all_confirmed_components_shared_structure_frames': shared_frames}
person = json.loads((root/'person.json').read_text())
report['person'] = {'labelled_frames': len(person), 'presence_confirmed_frames': sum(bool(r['component'] and r['component']['presence_confirmed']) for r in person), 'intersection_confirmed_frames': sum(bool(r['component'] and r['component']['intersection_confirmed']) for r in person)}
report['limitation'] = 'A zero count would not establish safety on real long or edge obstacles. Shared tunnel cross-section cells do not establish that the measured object is infrastructure.'
Path('build/issue23-alarm-mechanisms/positive-risk.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
