"""Evaluate completed actual negative replay and additive admission exposure."""
from collections import Counter
import gzip
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
plan = json.loads((root/'experiment.json').read_text())
out = Path(plan['output'])
completion = json.loads((out/'completion.json').read_text())
recordings = json.loads((out/'recordings.json').read_text())
reference = json.loads((Path(plan['reference'])/'recordings.json').read_text())
expected = {Path(e['path']).name:e['metadata_message_count'] for e in plan['recordings']}
violations = []
if not completion['complete'] or set(recordings)!=set(expected):
    violations.append('Incomplete workload coverage')
analysis = {}
for name,total in expected.items():
    measured = recordings[name]
    if measured['frames']!=total or measured['scientific_differences']:
        violations.append(f'{name}: missing frames or scientific differences')
    for field in ['frames','alarm_frames','alarm_episodes','status_frames']:
        if measured['baseline'][field]!=reference[name][field]:
            violations.append(f'{name}: baseline {field} differs')
    counts = Counter()
    alarm_transitions = []
    last = None
    examples = []
    with gzip.open(out/f'{name}-frames.jsonl.gz','rt') as stream:
        for line in stream:
            row = json.loads(line)
            counts['frames'] += 1
            obs = row['shape_observation']
            if obs.get('association_not_called'):
                counts['no_assignment_invocation'] += 1
            counts['frames_current_eligible'] += obs['eligible_current']>0
            counts['frames_previous_eligible'] += obs['eligible_previous']>0
            counts['frames_with_pairs'] += obs['native_pairs']>0
            counts['frames_with_matching_pairs'] += obs['matching_pairs']>0
            counts['unique_pair_frames'] += any(e['mutually_unique'] for e in obs['edges'])
            counts['new_alarm_frames'] += row['shadow_alarm'] and not row['alarm']
            counts['additional_components'] += len(row['additional_components'])
            counts['scientific_equal_frames'] += row['scientific_equal']
            for edge in obs['edges']:
                counts['matching_pairs'] += 1
                counts['mutually_unique_pairs'] += edge['mutually_unique']
                counts['unique_alternative_pairs'] += edge['mutually_unique'] and not edge['selected_by_global_assignment']
            if row['additional_components']:
                examples.append({k:row[k] for k in ['frame','measurement_timestamp_ns','alarm','shadow_alarm','split','additional_components']})
            if row['shadow_alarm']!=row['alarm']:
                alarm_transitions.append({'frame':row['frame'],'base_alarm':row['alarm'],'shadow_alarm':row['shadow_alarm']})
            last = row
    with gzip.open(out/f'{name}-exposures.jsonl.gz','rt') as stream:
        exposure_rows = [json.loads(line) for line in stream]
    grouped = Counter(r['kind'] for r in exposure_rows)
    if counts['frames']!=total or counts['scientific_equal_frames']!=total:
        violations.append(f'{name}: frame journal identity/coverage differs')
    if counts['new_alarm_frames']!=measured['counts']['new_alarm_frames'] or counts['additional_components']!=measured['counts']['additional_component_confirmations']:
        violations.append(f'{name}: exposure count inconsistency')
    if grouped['additional_shape_confirmation']!=counts['additional_components']:
        violations.append(f'{name}: missing exposure geometry')
    analysis[name]={'counts':dict(counts),'baseline':measured['baseline'],'shadow':measured['shadow'],
        'additional_frames':examples,'exposure_examples':exposure_rows[:10],
        'wall_s':measured['wall_s']}
additional = sum(r['counts']['additional_components'] for r in analysis.values())
new_frames = sum(r['counts']['new_alarm_frames'] for r in analysis.values())
report = {'hypothesis':plan['hypothesis'],'criterion':plan['criterion'],
    'shadow_contract':plan['shadow_contract'],'valid':not violations,'violations':violations,
    'frames':sum(r['counts']['frames'] for r in analysis.values()),
    'additional_component_confirmations':additional,'new_alarm_frames':new_frames,
    'baseline_alarm_episodes':sum(r['baseline']['alarm_episodes'] for r in analysis.values()),
    'shadow_alarm_episodes':sum(r['shadow']['alarm_episodes'] for r in analysis.values()),
    'baseline_alarm_frames':sum(r['baseline']['alarm_frames'] for r in analysis.values()),
    'shadow_alarm_frames':sum(r['shadow']['alarm_frames'] for r in analysis.values()),
    'recordings':analysis,'partitions':json.loads((out/'partitions.json').read_text()),
    'decision':{'negative_exposure_gate_passed':not violations and additional==0,
        'production_change':False,'promotion':False,
        'next_action': 'Reject direct adoption: added negative confirmations.' if additional else 'Negative exposure does not reject this mechanism; an actual isolated candidate and fixed positive/full-panel acceptance are still required.',
        'primary_metric_claim':'No actual modified candidate or primary improvement measured. Shadow episodes are admission exposure only.'},
    'seed':plan['seed'],'local_confirmation':plan['local_confirmation'],
    'manifest':json.loads((out/'manifest.json').read_text()),'limits':plan['limits']}
(root/'evaluation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['valid','violations','frames','additional_component_confirmations','new_alarm_frames','baseline_alarm_episodes','shadow_alarm_episodes','decision']},indent=2))
if violations:
    raise SystemExit('Negative replay validity failed')
