"""Actual fixed-negative replay with read-only native shape correspondence observation."""
import bisect
from collections import Counter
import gzip
import hashlib
import inspect
import json
import os
from pathlib import Path
import shutil
import sys
import time

import numpy as np
import tunnel_guard.detector as module
from tunnel_guard import _native
from tunnel_guard.io import iter_bag
from tunnel_guard.run import capture_native_sources, digest, environment, git_revision, write_json
from scripts.benchmark_issue23 import measure

plan = json.loads(Path(sys.argv[1]).read_text())
config = module.load_config(plan['detector_config'])
if config['seed'] != plan['seed'] or any(os.environ.get(k) != v for k,v in plan['thread_environment'].items()):
    raise ValueError('Seed/thread environment differs from recipe')
if config['confirmation_hits'] != 2:
    raise ValueError('This observation evaluates two-frame recurrence only; no silent generalization')
if config['local_confirmation'] != plan['local_confirmation']:
    raise ValueError('Shape thresholds differ from fixed recipe')
out = Path(plan['output'])
out.mkdir(parents=True, exist_ok=False)
write_json(out/'experiment.json',plan)
write_json(out/'detector.json',config)
source = out/'source'
shutil.copytree('tunnel_guard',source/'tunnel_guard',ignore=shutil.ignore_patterns('__pycache__','*.so'))
capture_native_sources(source)
shutil.copy2(__file__,source/'replay.py')
write_json(out/'manifest.json',environment() | {'git_revision':git_revision(),'command':sys.argv,
    'recipe_sha256':digest(Path(sys.argv[1])),'config_sha256':digest(Path(plan['detector_config'])),
    'panel_sha256':digest(Path(plan['panel_manifest'])),'native_binary_sha256':digest(Path(_native.__file__)),
    'reference_recordings_sha256':digest(Path(plan['reference'])/'recordings.json'),
    'thread_environment':plan['thread_environment'],
    'provenance_limit':'Metadata hash and retained file sizes checked; original bag bytes not rehashed.'})
original = module.linear_sum_assignment
observation = None
previous_objects = {}


def observe(cost):
    global observation
    result = original(cost)
    caller = inspect.currentframe().f_back
    try:
        v = caller.f_locals
        detector, objects, ids = v['self'], v['objects'], v['ids']
        cfg = detector.config
        eligible = [i for i,o in enumerate(objects) if o['path_relation']=='intersecting'
                    and o['certified_unexplained_voxels']>=cfg['claim_min_support_voxels']
                    and len(o['_support_points'])>=cfg['evidence_min_points']]
        previous = [key for key in ids if detector.tracks[key].get('local_frame')==detector.frame_number-1
                    and detector.tracks[key].get('local_shape') is not None]
        current_shapes = {j:objects[j]['_support_points']-v['centers'][j] for j in eligible}
        selected = {int(c):ids[int(r)] for r,c in zip(*result) if c<len(objects) and cost[r,c]<1e6}
        edges = []
        threshold = cfg['local_confirmation']['minimum_symmetric_overlap']
        radius = cfg['local_confirmation']['shape_radius_m']
        for key in previous:
            track = detector.tracks[key]
            prior = track['local_shape']
            r = ids.index(key)
            for j in eligible:
                current = current_shapes[j]
                forward = module.accelerator.keep_outside_radius(current,prior,radius,detector.native_kernels)
                backward = module.accelerator.keep_outside_radius(prior,current,radius,detector.native_kernels)
                overlap = min(1.0-float(forward.mean()),1.0-float(backward.mean()))
                if overlap >= threshold:
                    edges.append({'previous_track':key,'component_id':objects[j]['component_id'],
                        'column':j,'symmetric_overlap':overlap,'previous_hits':track.get('local_hits',0),
                        'previous_points':len(prior),'current_points':len(current),
                        'global_allowed':bool(v['allowed'][r,j]),'global_cost':float(cost[r,j]),
                        'mahalanobis':float(v['mahalanobis'][r,j]),
                        'selected_by_global_assignment':selected.get(j)==key})
        by_current = Counter(e['component_id'] for e in edges)
        by_previous = Counter(e['previous_track'] for e in edges)
        unique = []
        for e in edges:
            e['mutually_unique'] = by_current[e['component_id']]==1 and by_previous[e['previous_track']]==1
            if e['mutually_unique']:
                j,key = e['column'],e['previous_track']
                unique.append({'edge':e,'current_shape':current_shapes[j],
                               'previous_shape':detector.tracks[key]['local_shape']})
        observation = {'frame':detector.frame_number-1,'motion_valid':bool(v['motion']['valid']),
            'eligible_current':len(eligible),'eligible_previous':len(previous),
            'native_pairs':len(eligible)*len(previous),'matching_pairs':len(edges),
            'current_without_match':sum(objects[j]['component_id'] not in by_current for j in eligible),
            'current_multiple_matches':sum(n>1 for n in by_current.values()),
            'previous_multiple_matches':sum(n>1 for n in by_previous.values()),
            'edges':edges,'unique':unique}
        return result
    finally:
        del caller


ignored = set(plan['ignored_elapsed_fields'])
def scientific(row):
    return {k:v for k,v in row.items() if k not in ignored}

def signature(row):
    return hashlib.sha256(json.dumps(scientific(row),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

summaries = {}
partitions = {}
module.linear_sum_assignment = observe
try:
    for entry in plan['recordings']:
        bag = Path(entry['path'])
        name = bag.name
        if digest(bag/'metadata.yaml') != entry['metadata_sha256']:
            raise ValueError(f'Bag metadata changed: {name}')
        for file in entry.get('files',entry.get('segments',[])):
            if (bag/file.get('name',file.get('file'))).stat().st_size != file['bytes']:
                raise ValueError(f'Bag file size changed: {name}')
        detector = module.Detector(config)
        previous_objects = {}
        counts = Counter()
        base_sequence,shadow_sequence = [],[]
        differences = []
        seen = set()
        started = time.perf_counter()
        segments = sorted(entry.get('segments',[]),key=lambda s:s['record_start_ns'])
        starts = [s['record_start_ns'] for s in segments]
        reference_path = Path(plan['reference'])/f'{name}.jsonl.gz'
        with gzip.open(reference_path,'rt') as reference, gzip.open(out/f'{name}-frames.jsonl.gz','wt',compresslevel=1) as frames, gzip.open(out/f'{name}-exposures.jsonl.gz','wt',compresslevel=1) as exposures:
            for scan in iter_bag(bag,config,every=1,max_frames=plan.get('max_frames_per_recording')):
                if scan.index != len(base_sequence) or scan.measurement_timestamp_ns in seen:
                    raise ValueError('Missing/reordered/duplicate acquisition')
                seen.add(scan.measurement_timestamp_ns)
                observation = None
                row = detector.process(scan.points,scan.timestamp_s,scan.point_times,point_attributes=scan.attributes)
                row.update(frame=scan.index,measurement_timestamp_ns=scan.measurement_timestamp_ns,
                    record_timestamp_ns=scan.record_timestamp_ns,
                    source_scan_id=f'{scan.topic}:{scan.frame_id}:{scan.measurement_timestamp_ns}')
                expected = json.loads(next(reference))
                changed = [k for k in set(row)|set(expected) if k not in ignored and row.get(k)!=expected.get(k)]
                if changed:
                    differences.append({'frame':scan.index,'fields':changed})
                    exposures.write(json.dumps({'kind':'scientific_difference','actual':row,'expected':expected},allow_nan=False)+'\n')
                before = any(o['intersection_confirmed'] for o in row['objects'])
                objects = {o['component_id']:o for o in row['objects']}
                added = []
                trace = observation or {'frame':scan.index,'eligible_current':0,'eligible_previous':0,
                    'native_pairs':0,'matching_pairs':0,'current_without_match':0,'current_multiple_matches':0,
                    'previous_multiple_matches':0,'edges':[],'unique':[],'association_not_called':True}
                for key in ['native_pairs','matching_pairs','eligible_current','eligible_previous','current_without_match','current_multiple_matches','previous_multiple_matches']:
                    counts[key] += trace[key]
                counts['frames_with_shape_ambiguity'] += bool(trace['current_multiple_matches'] or trace['previous_multiple_matches'])
                unique = trace.pop('unique')
                counts['mutually_unique_pairs'] += len(unique)
                if not row.get('motion',{}).get('valid',False):
                    counts['motion_invalid_frames'] += 1
                    for match in unique:
                        e = match['edge']
                        obj = objects[e['component_id']]
                        if not obj['intersection_confirmed']:
                            added.append(obj['component_id'])
                            exposures.write(json.dumps({'kind':'additional_shape_confirmation','frame':scan.index,
                                'measurement_timestamp_ns':scan.measurement_timestamp_ns,'base_status':row['status'],
                                'base_alarm':before,'edge':e,'current_object':obj,
                                'previous_object':previous_objects.get(e['previous_track']),
                                'current_centered_shape':match['current_shape'].tolist(),
                                'previous_centered_shape':match['previous_shape'].tolist(),
                                'geometry':row.get('geometry'),'motion':row.get('motion'),
                                'supported_range_m':row.get('supported_range_m')},allow_nan=False)+'\n')
                after = before or bool(added)
                counts['additional_component_confirmations'] += len(added)
                counts['new_alarm_frames'] += after and not before
                item = {k:row[k] for k in ('frame','measurement_timestamp_ns','record_timestamp_ns','status')}
                item['alarm'] = before
                base_sequence.append(item)
                shadow = dict(item,alarm=after,status='obstacle' if after else row['status'])
                shadow_sequence.append(shadow)
                split = entry.get('split')
                if segments:
                    segment_index = bisect.bisect_right(starts,scan.record_timestamp_ns)-1
                    if segment_index < 0:
                        raise ValueError('Record precedes frozen segments')
                    segment = segments[segment_index]
                    if scan.record_timestamp_ns > segment['record_start_ns']+round(segment['record_duration_s']*1e9):
                        raise ValueError('Record outside frozen segment')
                    split = segment['split']
                partition = partitions.setdefault(split,{'baseline':[],'shadow':[]})
                partition['baseline'].append(dict(item,recording=name))
                partition['shadow'].append(dict(shadow,recording=name))
                frames.write(json.dumps(item | {'shadow_alarm':after,'split':split,'additional_components':added,
                    'scientific_equal':not changed,'scientific_sha256':signature(row),'shape_observation':trace},allow_nan=False)+'\n')
                previous_objects = {o['track_id']:o for o in row['objects']}
                if len(base_sequence)%250==0:
                    frames.flush(); exposures.flush()
                    print(json.dumps({'recording':name,'frames':len(base_sequence),'additional_components':counts['additional_component_confirmations'],'new_alarm_frames':counts['new_alarm_frames'],'scientific_differences':len(differences)}),flush=True)
            if plan.get('max_frames_per_recording') is None and next(reference,None) is not None:
                raise ValueError('Reference contains additional acquisitions')
        expected_frames = min(entry['metadata_message_count'],plan.get('max_frames_per_recording') or entry['metadata_message_count'])
        if len(base_sequence)!=expected_frames:
            raise ValueError(f'Incomplete recording: {name}')
        summaries[name] = {'frames':len(base_sequence),'scientific_differences':differences,
            'counts':dict(counts),'baseline':measure(base_sequence,round(plan['frame_max_gap_s']*1e9)),
            'shadow':measure(shadow_sequence,round(plan['frame_max_gap_s']*1e9)),
            'wall_s':time.perf_counter()-started,'reference_rows_sha256':digest(reference_path)}
        write_json(out/'recordings.json',summaries)
        print(json.dumps({'completed':name,**summaries[name]}),flush=True)
        if differences:
            raise ValueError('Observation changed scientific output; stop rather than interpret it')
    # Keep recording boundaries explicit: timestamps from separate bags need not be ordered.
    partition_report = {}
    for split,sequences in partitions.items():
        partition_report[split] = {}
        for mode,sequence in sequences.items():
            by_bag = {}
            for item in sequence:
                by_bag.setdefault(item['recording'],[]).append(item)
            metrics = [measure(items,round(plan['frame_max_gap_s']*1e9)) for items in by_bag.values()]
            partition_report[split][mode] = {key:sum(m[key] for m in metrics) for key in ['frames','alarm_frames','alarm_episodes']}
    write_json(out/'partitions.json',partition_report)
    write_json(out/'completion.json',{'complete':True,'frames':sum(r['frames'] for r in summaries.values()),
        'scientific_identity':all(not r['scientific_differences'] for r in summaries.values()),
        'additional_component_confirmations':sum(r['counts']['additional_component_confirmations'] for r in summaries.values()),
        'new_alarm_frames':sum(r['counts']['new_alarm_frames'] for r in summaries.values()),
        'limits':plan['limits']})
finally:
    module.linear_sum_assignment = original
