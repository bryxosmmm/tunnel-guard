"""Actual person recording replay with unchanged authored-box correspondence evaluation."""
from collections import Counter
import gzip
import json
import os
from pathlib import Path
import shutil
import sys
import time
import numpy as np
from tunnel_guard import _native
from tunnel_guard.detector import Detector, load_config
from tunnel_guard.io import iter_bag
from tunnel_guard.person_evidence_report import box_geometry, in_oriented_box, oriented_iou
from tunnel_guard.run import capture_native_sources, digest, environment, write_json
from tunnel_guard.sustech import read_box_files

plan = json.loads(Path(sys.argv[1]).read_text())
config = load_config(plan['detector_config'])
if config['seed']!=plan['seed'] or any(os.environ.get(k)!=v for k,v in plan['thread_environment'].items()):
    raise ValueError('Seed/thread recipe mismatch')
labels = read_box_files(Path(plan['source_labels']))
if sorted(labels)!=plan['label_frames']:
    raise ValueError('Authored label panel changed')
bag = Path(plan['bag'])
if digest(bag/'metadata.yaml')!=plan['bag_metadata_sha256']:
    raise ValueError('Bag metadata changed')
for file in plan['bag_files']:
    if (bag/file['name']).stat().st_size!=file['bytes']:
        raise ValueError('Bag file size changed')
out = Path(plan['output'])
out.mkdir(parents=True,exist_ok=False)
write_json(out/'experiment.json',plan)
write_json(out/'detector.json',config)
shutil.copytree(Path(_native.__file__).parent,out/'source/tunnel_guard',ignore=shutil.ignore_patterns('__pycache__','*.so'))
capture_native_sources(out/'source')
shutil.copy2(__file__,out/'replay.py')
write_json(out/'manifest.json',environment() | {'base_commit':plan['base_commit'],'command':sys.argv,
    'native_path':str(_native.__file__),'native_sha256':digest(Path(_native.__file__)),
    'config_sha256':digest(Path(plan['detector_config'])),'recipe_sha256':digest(Path(sys.argv[1])),
    'label_sha256':{str(p):digest(p) for p in sorted(Path(plan['source_labels']).glob('*.json'))},
    'source_sha256':{str(p.relative_to(out/'source')):digest(p) for p in (out/'source').rglob('*') if p.is_file()}})
detector = Detector(config)
person = []
seen = set()
counts = Counter()
started = time.perf_counter()
count = 0
with gzip.open(out/'doubleT_obstacle.jsonl.gz','wt',compresslevel=1) as stream:
    for scan in iter_bag(bag,config,every=1,max_frames=plan['expected_frames']):
        if scan.index!=count or scan.measurement_timestamp_ns in seen:
            raise ValueError('Acquisition order changed')
        seen.add(scan.measurement_timestamp_ns)
        row=detector.process(scan.points,scan.timestamp_s,scan.point_times,
            capture_diagnostics=scan.index in labels,point_attributes=scan.attributes)
        row.update(frame=scan.index,measurement_timestamp_ns=scan.measurement_timestamp_ns,
            record_timestamp_ns=scan.record_timestamp_ns,
            source_scan_id=f'{scan.topic}:{scan.frame_id}:{scan.measurement_timestamp_ns}')
        stream.write(json.dumps(row,allow_nan=False)+'\n')
        if scan.index in labels:
            arrays=detector.diagnostic_arrays
            box=labels[scan.index][0]
            center,scale,rotation,_=box_geometry(box)
            mask=in_oriented_box(arrays['cluster_points'],center,scale,rotation)
            members=Counter(int(v) for v in arrays['cluster_labels'][mask] if v>=0)
            ranked=sorted((o for o in row['objects'] if members[o['component_id']]),key=lambda o:(-members[o['component_id']],o['component_id']))
            best=ranked[0] if ranked else None
            person.append({'frame':scan.index,'component':best,
                'component_points_inside_obb':members[best['component_id']] if best else 0,
                'oriented_iou':oriented_iou(best,center,scale,rotation,plan['numerical_epsilon']) if best else 0.,
                'center_error_m':float(np.linalg.norm(np.asarray(best['center'])-center)) if best else None})
        counts[row['status']]+=1
        count+=1
if count!=plan['expected_frames']:
    raise ValueError('Incomplete person recording')
write_json(out/'person.json',person)
summary={'frames':count,'status_frames':dict(counts),'wall_s':time.perf_counter()-started}
write_json(out/'summary.json',summary)
print(json.dumps(summary))
