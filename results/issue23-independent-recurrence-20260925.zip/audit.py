"""Audit every candidate output change, including unlabelled component confirmations."""
from collections import Counter, defaultdict
import gzip
import itertools
import json
from pathlib import Path
import sys

plan=json.loads(Path(sys.argv[1]).read_text())
mode=sys.argv[2]
root=Path(plan['root'])
best=Path(plan['best'])
entry=plan['recordings'][mode]
actual=root/mode
ignored=set(plan['ignored_elapsed_fields'])
row_allowed=set(plan['allowed_decision_fields'])
object_allowed=set(plan['allowed_local_evidence_fields'])
attribution=defaultdict(list)
if mode=='synthetic':
    events=json.loads((actual/'synthetic.json').read_text())
    for event,rows in events.items():
        for row in rows:
            for obj in row['components']:
                attribution[row['frame'],obj['component_id']].append(int(event))
else:
    person=json.loads((actual/'person.json').read_text())
    for row in person:
        if row['component']:
            attribution[row['frame'],row['component']['component_id']].append('authored_person')
violations=[]
changes=[]
additions=[]
losses=[]
field_counts=Counter()
frames=0
with gzip.open(actual/entry['rows'],'rt') as a,gzip.open(best/entry['rows'],'rt') as b:
    for frame,pair in enumerate(itertools.zip_longest(a,b)):
        if None in pair:
            violations.append({'kind':'length_mismatch','frame':frame}); break
        left,right=map(json.loads,pair)
        frames+=1
        changed=[k for k in set(left)|set(right) if k not in ignored and k!='objects' and left.get(k)!=right.get(k)]
        unexpected=[k for k in changed if k not in row_allowed]
        if 'pipeline' in unexpected:
            # detector.py derives this diagnostic directly from current flags.
            # Admit that exact counter change, never arbitrary pipeline changes.
            prior_association=right['pipeline'].get('association',{})
            if prior_association.get('confirmed')==sum(bool(o.get('confirmed',False)) for o in right['objects']):
                expected_pipeline=right['pipeline'] | {'association':prior_association | {
                    'confirmed':sum(bool(o.get('confirmed',False)) for o in left['objects'])}}
                if left['pipeline']==expected_pipeline:
                    unexpected.remove('pipeline')
        if unexpected:
            violations.append({'kind':'unexpected_row_fields','frame':frame,'fields':unexpected})
        left_objects,right_objects=left['objects'],right['objects']
        if [(o['component_id'],o['track_id']) for o in left_objects]!=[(o['component_id'],o['track_id']) for o in right_objects]:
            violations.append({'kind':'component_or_global_identity_changed','frame':frame})
            continue
        object_changes=[]
        for obj,old in zip(left_objects,right_objects):
            fields=sorted(k for k in set(obj)|set(old) if obj.get(k)!=old.get(k))
            unexpected_obj=[k for k in fields if k not in object_allowed]
            if unexpected_obj:
                violations.append({'kind':'unexpected_component_fields','frame':frame,'component_id':obj['component_id'],'fields':unexpected_obj})
            if fields:
                object_changes.append({'component_id':obj['component_id'],'track_id':obj['track_id'],
                    'attribution':attribution[frame,obj['component_id']],
                    'fields':{k:{'before':old.get(k),'after':obj.get(k)} for k in fields}})
                field_counts.update(fields)
            for key in ['presence_confirmed','intersection_confirmed']:
                if old.get(key, False) and not obj.get(key, False):
                    losses.append({'frame':frame,'component_id':obj['component_id'],'field':key,'attribution':attribution[frame,obj['component_id']]})
                if obj.get(key, False) and not old.get(key, False):
                    additions.append({'frame':frame,'field':key,'attribution':attribution[frame,obj['component_id']],
                        'baseline_status':right['status'],'candidate_status':left['status'],
                        'motion_valid':left['motion']['valid'],'before':old,'after':obj})
        if changed or object_changes:
            changes.append({'frame':frame,'row_fields':{k:{'before':right.get(k),'after':left.get(k)} for k in changed},'objects':object_changes})
if frames!=entry['frames']:
    violations.append({'kind':'incomplete_expected_recording','actual':frames,'expected':entry['frames']})
person_result=None
if mode=='person':
    expected=json.loads((best/'person.json').read_text())
    if [r['frame'] for r in person]!=[r['frame'] for r in expected]:
        violations.append({'kind':'person_label_panel_changed'})
    localization_changes=[]
    for left,right in zip(person,expected):
        for key in ['component_points_inside_obb','oriented_iou','center_error_m']:
            if left[key]!=right[key]:
                localization_changes.append({'frame':left['frame'],'field':key,'before':right[key],'after':left[key]})
        if (left['component'] is None)!=(right['component'] is None):
            localization_changes.append({'frame':left['frame'],'field':'selected_component_presence'})
        elif left['component'] and (left['component']['component_id'],left['component']['track_id'])!=(right['component']['component_id'],right['component']['track_id']):
            localization_changes.append({'frame':left['frame'],'field':'selected_component_identity'})
    ids=[r['component']['track_id'] for r in person if r['component']]
    person_result={'labelled_frames':len(person),'presence_confirmed_frames':sum(bool(r['component'] and r['component']['presence_confirmed']) for r in person),
        'intersection_confirmed_frames':sum(bool(r['component'] and r['component']['intersection_confirmed']) for r in person),
        'track_switches':sum(a!=b for a,b in zip(ids,ids[1:])), 'localization_and_membership_changes':localization_changes}
    if localization_changes:
        violations.append({'kind':'person_localization_or_correspondence_changed'})
if losses:
    violations.append({'kind':'lost_baseline_component_confirmation','count':len(losses)})
result={'mode':mode,'frames':frames,'valid':not violations,'violations':violations,
    'changed_frames':len(changes),'changed_component_field_counts':dict(field_counts),
    'additional_presence_components':sum(r['field']=='presence_confirmed' for r in additions),
    'additional_intersection_components':sum(r['field']=='intersection_confirmed' for r in additions),
    'unattributed_additional_intersection_components':sum(r['field']=='intersection_confirmed' and not r['attribution'] for r in additions),
    'lost_confirmations':losses,'person':person_result,'all_changes':changes,'all_additions':additions,
    'limits':plan['limits']}
(root/f'{mode}-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['mode','frames','valid','violations','changed_frames','additional_presence_components','additional_intersection_components','unattributed_additional_intersection_components','person']},indent=2))
if violations:
    raise SystemExit('Candidate audit failed')
