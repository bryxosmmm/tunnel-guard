import cProfile
import gzip
import hashlib
import json
import os
from pathlib import Path
import pstats
import shutil
import sys
import time
import tunnel_guard.detector as module
from tunnel_guard import _native
from tunnel_guard.io import iter_bag
from tunnel_guard.run import capture_native_sources, digest, environment, write_json

plan=json.loads(Path(sys.argv[1]).read_text())
source_root=Path(plan.get('source_root','.')).resolve()
if Path(module.__file__).resolve().parent != source_root/'tunnel_guard':
    raise ValueError('Imported source differs from configured source root')
config=module.load_config(plan['detector_config'])
if digest(Path(plan['detector_config']))!=plan['config_sha256'] or config['seed']!=plan['seed']:
    raise ValueError('Frozen config changed')
for name,expected in plan['source_sha256'].items():
    if digest(source_root/name)!=expected: raise ValueError('Frozen source changed: '+name)
if digest(Path(_native.__file__))!=plan['native_sha256']:
    raise ValueError('Frozen native changed')
if any(os.environ.get(k)!=v for k,v in plan['thread_environment'].items()):
    raise ValueError('Thread environment changed')
out=Path(plan['output']);out.mkdir(parents=True,exist_ok=False)
write_json(out/'experiment.json',plan);write_json(out/'detector.json',config)
shutil.copy2(__file__,out/'replay.py');capture_native_sources(out/'source')
write_json(out/'manifest.json',environment()|{'native_sha256':plan['native_sha256'],'source_sha256':plan['source_sha256']})
ignored=set(plan['ignored_elapsed_fields'])
summary={}

def write_row(stream,row):
    stream.write(json.dumps(row)+'\n')

for entry in plan['recordings']:
    bag=Path(entry['path']);name=bag.name
    if digest(bag/'metadata.yaml')!=entry['metadata_sha256']:
        raise ValueError('Bag metadata changed')
    for part in entry.get('files',entry.get('segments',[])):
        if (bag/part.get('name',part.get('file'))).stat().st_size!=part['bytes']:
            raise ValueError('Bag segment changed')
    detector=module.Detector(config)
    profiles={key:cProfile.Profile() for key in ['decode','detector','gzip_write']}
    scans=iter_bag(bag,config,every=1,max_frames=plan['frames_per_recording'])
    signatures=[];started=time.perf_counter()
    writer=gzip.open(out/(name+'.jsonl.gz'),'wt')
    try:
        with gzip.open(Path(plan['reference'])/(name+'.jsonl.gz'),'rt') as reference:
            for index in range(plan['frames_per_recording']):
                scan=profiles['decode'].runcall(next,scans)
                if scan.index!=index: raise ValueError('Acquisition order changed')
                row=profiles['detector'].runcall(detector.process,scan.points,scan.timestamp_s,scan.point_times,point_attributes=scan.attributes,capture_diagnostics=False)
                row.update(frame=scan.index,measurement_timestamp_ns=scan.measurement_timestamp_ns,record_timestamp_ns=scan.record_timestamp_ns,source_scan_id=f'{scan.topic}:{scan.frame_id}:{scan.measurement_timestamp_ns}')
                expected=json.loads(next(reference))
                changes=[key for key in row.keys()|expected.keys() if key not in ignored and row.get(key)!=expected.get(key)]
                if changes:
                    write_json(out/'identity-failure.json',{'recording':name,'frame':index,'fields':changes,'actual':row,'expected':expected})
                    raise ValueError('Scientific output changed')
                scientific={key:value for key,value in row.items() if key not in ignored}
                signatures.append({'frame':index,'scientific_sha256':hashlib.sha256(json.dumps(scientific,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()})
                profiles['gzip_write'].runcall(write_row,writer,row)
    finally:
        profiles['gzip_write'].runcall(writer.close)
        scans.close()
    stages={}
    for key,profile in profiles.items():
        profile.dump_stats(str(out/(name+'-'+key+'.pstats')))
        stats=pstats.Stats(profile)
        rows=[{'file':site[0],'line':site[1],'function':site[2],'primitive_calls':v[0],'calls':v[1],'self_s':v[2],'cumulative_s':v[3]} for site,v in stats.stats.items()]
        stages[key]={'profile_total_s':stats.total_tt,'calls':stats.total_calls,'top_self':sorted(rows,key=lambda r:r['self_s'],reverse=True)[:40],'top_cumulative':sorted(rows,key=lambda r:r['cumulative_s'],reverse=True)[:40]}
    write_json(out/(name+'-profiles.json'),stages)
    write_json(out/(name+'-scientific-digests.json'),signatures)
    summary[name]={'frames':len(signatures),'scientific_identity':True,'wall_s':time.perf_counter()-started,'stage_profile_s':{key:value['profile_total_s'] for key,value in stages.items()}}
    write_json(out/'summary.json',summary)
    print(json.dumps({'completed':name,**summary[name]}),flush=True)
