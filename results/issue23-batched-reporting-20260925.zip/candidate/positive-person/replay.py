import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import tunnel_guard.detector as module
from tunnel_guard import _native
from tunnel_guard.io import iter_bag
from tunnel_guard.run import digest,environment,write_json

plan=json.loads(Path(sys.argv[1]).read_text())
source=Path(plan['source_root']).resolve()
if Path(module.__file__).resolve().parent!=source/'tunnel_guard': raise ValueError('Wrong imported source')
config=module.load_config(plan['detector_config'])
if digest(Path(plan['detector_config']))!=plan['config_sha256'] or config['seed']!=plan['seed']: raise ValueError('Config changed')
for name,expected in plan['source_sha256'].items():
    if digest(source/name)!=expected: raise ValueError('Source changed: '+name)
if digest(Path(_native.__file__))!=plan['native_sha256']: raise ValueError('Native changed')
if any(os.environ.get(k)!=v for k,v in plan['thread_environment'].items()): raise ValueError('Thread environment changed')
out=Path(plan['output']);out.mkdir(parents=True,exist_ok=False)
write_json(out/'experiment.json',plan);write_json(out/'manifest.json',environment())
shutil.copy2(__file__,out/'replay.py')
ignored=set(plan['ignored_elapsed_fields'])
summary={}
for entry in plan['recordings']:
    bag=Path(entry['path']);name=bag.name
    if digest(bag/'metadata.yaml')!=entry['metadata_sha256']: raise ValueError('Metadata changed')
    for part in entry.get('files',entry.get('segments',[])):
        if (bag/part.get('name',part.get('file'))).stat().st_size!=part['bytes']: raise ValueError('Segment changed')
    detector=module.Detector(config);measurements=[]
    diagnostic_frames=set(plan.get('diagnostic_frames',{}).get(name,[]))
    limit=entry.get('replay_frames',plan['frames_per_recording'])
    scans=iter_bag(bag,config,every=1,max_frames=limit)
    with gzip.open(Path(plan['reference'])/(name+'.jsonl.gz'),'rt') as reference,gzip.open(out/(name+'.jsonl.gz'),'wt',compresslevel=6) as rows:
        for index,scan in enumerate(scans):
            if scan.index!=index: raise ValueError('Acquisition order changed')
            started=time.perf_counter_ns();cpu_started=time.process_time_ns()
            row=detector.process(scan.points,scan.timestamp_s,scan.point_times,point_attributes=scan.attributes,capture_diagnostics=index in diagnostic_frames)
            cpu_s=(time.process_time_ns()-cpu_started)*1e-9;elapsed_s=(time.perf_counter_ns()-started)*1e-9
            row.update(frame=scan.index,measurement_timestamp_ns=scan.measurement_timestamp_ns,record_timestamp_ns=scan.record_timestamp_ns,source_scan_id=f'{scan.topic}:{scan.frame_id}:{scan.measurement_timestamp_ns}')
            expected=json.loads(next(reference))
            changes=[key for key in row.keys()|expected.keys() if key not in ignored and row.get(key)!=expected.get(key)]
            if changes:
                write_json(out/'identity-failure.json',{'recording':name,'frame':index,'fields':changes,'actual':row,'expected':expected})
                raise ValueError('Scientific output changed')
            scientific={key:value for key,value in row.items() if key not in ignored}
            measurements.append({'frame':index,'measurement_timestamp_ns':scan.measurement_timestamp_ns,'elapsed_s':elapsed_s,'cpu_s':cpu_s,'objects':len(row['objects']),'scientific_sha256':hashlib.sha256(json.dumps(scientific,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()})
            rows.write(json.dumps(row)+'\n')
    if len(measurements)!=limit: raise ValueError('Incomplete replay')
    write_json(out/(name+'-measurements.json'),measurements)
    timed=measurements[plan['warmup_frames']:]
    summary[name]={'frames':len(measurements),'timed_frames':len(timed),'scientific_identity':True,'processing_elapsed_s':sum(r['elapsed_s'] for r in timed),'processing_cpu_s':sum(r['cpu_s'] for r in timed)}
    write_json(out/'summary.json',summary)
    print(json.dumps({'completed':name,**summary[name]}),flush=True)
