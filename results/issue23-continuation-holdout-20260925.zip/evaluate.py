"""Numerical evaluation on real saved anchor measurements; no detector decisions changed."""
import gzip
import hashlib
import json
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from tunnel_guard.geometry import TrackGeometry

plan_path = Path(sys.argv[1])
plan = json.loads(plan_path.read_text())
for path_key, hash_key in [('config', 'config_sha256'), ('geometry_source', 'geometry_sha256')]:
    if hashlib.sha256(Path(plan[path_key]).read_bytes()).hexdigest() != plan[hash_key]:
        raise ValueError('Frozen estimator source/config changed')
config = json.loads(Path(plan['config']).read_text())
root = Path(plan['reference_root'])
output = Path(plan['outputs'])
output.mkdir(parents=True, exist_ok=False)
(output/'experiment.json').write_text(json.dumps(plan, indent=2)+'\n')
(output/'geometry.py').write_bytes(Path(plan['geometry_source']).read_bytes())
(output/'detector.json').write_bytes(Path(plan['config']).read_bytes())
(output/'evaluate.py').write_bytes(Path(__file__).read_bytes())
# Reconstitute only the two recorded fields read by these exact production methods.
# This is deliberately not a fitted/full TrackGeometry or a raw Detector replay.
path_state = TrackGeometry.__new__(TrackGeometry)
path_state.config = config
groups = defaultdict(list)
counts = Counter()
inputs = []
started = time.perf_counter()
with gzip.open(output/'holdouts.jsonl.gz', 'wt') as journal:
    for recording in plan['recordings']:
        name = recording['name']
        path = root/(name+'.jsonl.gz')
        if path.stat().st_size != recording['bytes']:
            raise ValueError('Saved input changed size')
        with path.open('rb') as source:
            source_sha = hashlib.file_digest(source, 'sha256').hexdigest()
        frame_count = 0
        with gzip.open(path, 'rt') as stream:
            for frame, line in enumerate(stream):
                row = json.loads(line)
                frame_count += 1
                counts['frames'] += 1
                geometry = row.get('geometry') or {}
                anchors = np.asarray(geometry.get('rail_anchors', []), dtype=float)
                if len(anchors) < 3:
                    counts['insufficient_retained_anchors'] += 1
                    continue
                if not np.all(np.diff(anchors[:, 0]) > 0):
                    raise ValueError('Non-increasing retained anchor positions')
                path_state.rail_anchors = anchors
                x = np.array([anchors[-1, 0]])
                _, _, measured_uncertainty = path_state.path(x)
                path_state.rail_anchors = anchors[:-1]
                prediction, _, uncertainty = path_state.path(x)
                fit = path_state._continuation(-1)
                training = anchors[:-1]
                selected = training[training[:, 0] >= training[-1, 0]-config['path_curve_window_m']]
                error = float(prediction[0]-anchors[-1, 1])
                finite = bool(np.isfinite(uncertainty[0]))
                u = float(uncertainty[0]) if finite else None
                negative_alarm = recording['role'] in {'organizer_declared_empty', 'continuous_negative'} and row['status']=='obstacle'
                observation = {'recording':name, 'frame':frame, 'role':recording['role'],
                    'baseline_status':row['status'], 'negative_alarm':negative_alarm,
                    'retained_anchors':anchors.tolist(), 'training_selected_anchors':len(selected),
                    'nonzero_design_rows':max(len(selected)-1, 0),
                    'quadratic_residual_dof_if_rank_two':len(selected)-3,
                    'continuation_coefficients':list(fit),
                    'holdout_distance_m':float(x[0]-training[-1, 0]),
                    'predicted_center_m':float(prediction[0]), 'measured_center_m':float(anchors[-1, 1]),
                    'signed_discrepancy_m':error, 'prediction_heuristic_uncertainty_m':u,
                    'measured_anchor_heuristic_uncertainty_m':float(measured_uncertainty[0]),
                    'outside_prediction_interval':bool(finite and abs(error)>u),
                    'outside_prediction_plus_anchor_interval':bool(finite and abs(error)>u+measured_uncertainty[0]),
                    'prediction_within_configured_uncertainty_limit':bool(finite and u<=config['path_max_uncertainty_m'])}
                journal.write(json.dumps(observation, allow_nan=False)+'\n')
                counts['holdouts'] += 1
                for key in ['all', 'recording:'+name, 'selected:'+str(len(selected))]:
                    groups[key].append(observation)
                if negative_alarm:
                    groups['negative_alarm'].append(observation)
        if frame_count != recording['frames']:
            raise ValueError('Incomplete saved recording')
        inputs.append({'recording':name, 'frames':frame_count, 'sha256':source_sha})
        print(json.dumps({'completed':name, 'frames':frame_count}), flush=True)
summary = {}
for key, observations in groups.items():
    errors = np.abs([item['signed_discrepancy_m'] for item in observations])
    summary[key] = {'holdouts':len(observations),
        'absolute_discrepancy_quantiles_m':dict(zip(['min','median','p90','p99','max'], map(float,np.quantile(errors,[0,.5,.9,.99,1])))),
        **{field:sum(item[field] for item in observations) for field in ['outside_prediction_interval','outside_prediction_plus_anchor_interval','prediction_within_configured_uncertainty_limit']}}
report = {'counts':dict(counts), 'groups':summary, 'inputs':inputs,
          'wall_s':time.perf_counter()-started, 'interpretation':plan['interpretation'],
          'decision':'Diagnostic only. Retained-anchor discrepancies cannot establish true rail geometry, justify suppression, or validate a straight-line fallback.'}
(output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
