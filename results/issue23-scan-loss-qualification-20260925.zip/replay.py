"""Actual deterministic whole-scan-loss experiment; no generated points or mocked decisions."""
from collections import Counter
import functools
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import numpy as np
from tunnel_guard import _native
from tunnel_guard.detector import Detector, load_config
from tunnel_guard.io import iter_bag
from tunnel_guard.run import capture_native_sources, digest, environment, write_json

plan=json.loads(Path(sys.argv[1]).read_text())
variant=sys.argv[2]
spec=plan['variants'][variant]
config=load_config(plan['detector_config'])
package=Path(sys.modules[Detector.__module__].__file__).parent
if package.resolve()!=Path(spec['package']).resolve():
    raise ValueError('Wrong runtime package selected')
if digest(package/'detector.py')!=spec['detector_sha256'] or digest(Path(_native.__file__))!=spec['native_sha256']:
    raise ValueError('Runtime source/native identity changed')
if digest(Path(plan['detector_config']))!=plan['config_sha256'] or config['seed']!=plan['seed']:
    raise ValueError('Configuration identity changed')
if any(os.environ.get(k)!=v for k,v in plan['thread_environment'].items()):
    raise ValueError('Thread/seed environment differs from fixed recipe')
out=Path(plan['output'])/variant
out.mkdir(parents=True,exist_ok=False)
shutil.copytree(package,out/'source/tunnel_guard',ignore=shutil.ignore_patterns('__pycache__','*.so'))
capture_native_sources(out/'source')
shutil.copy2(__file__,out/'replay.py')
write_json(out/'experiment.json',plan)
write_json(out/'detector.json',config)
write_json(out/'manifest.json',environment() | {'variant':variant,'command':sys.argv,
    'recipe_sha256':digest(Path(sys.argv[1])),'config_sha256':plan['config_sha256'],
    'native_path':str(_native.__file__),'native_sha256':digest(Path(_native.__file__)),
    'package_path':str(package),'source_hashes':{str(p.relative_to(out/'source')):digest(p) for p in (out/'source').rglob('*') if p.is_file()},
    'input_provenance':'Metadata SHA256 and bag sizes checked; selected decoded XYZ/time/attributes fingerprinted per acquisition. Whole bags not rehashed.'})


def input_digest(scan):
    h=hashlib.sha256()
    arrays={'points':scan.points,'point_times':scan.point_times}
    if scan.attributes is not None:
        arrays.update({'attribute_'+k:v for k,v in scan.attributes.values.items()})
        arrays['source_indices']=scan.attributes.source_indices
        arrays['xyz_valid_mask']=scan.attributes.xyz_valid_mask
    for key,arr in sorted(arrays.items()):
        arr=np.ascontiguousarray(arr)
        h.update(json.dumps([key,arr.dtype.str,arr.shape]).encode())
        if arr.size:
            h.update(memoryview(arr).cast('B'))
    h.update(json.dumps([scan.index,scan.measurement_timestamp_ns,scan.record_timestamp_ns,scan.topic,scan.frame_id,scan.raw_points,scan.invalid_points,scan.attributes.time_field if scan.attributes else None]).encode())
    return h.hexdigest()


def instrument(detector, captured):
    original=detector._associate
    code=original.__func__.__code__
    def profile(frame,event,arg):
        if frame.f_code is not code or event!='return':
            return
        v=frame.f_locals
        objects=v['objects']
        matches=v.get('matches',{})
        fallback=v.get('local_fallback',{})
        previous={key:(shape,hits) for key,shape,hits in v.get('previous',[])}
        current=v.get('local_shapes',{})
        edges=[]
        alternatives=[]
        for index,pairs in matches.items():
            for key,overlap,hits in pairs:
                unique=index in fallback
                alternative=unique and v['matched'].get(index)!=key
                edge={'component_id':objects[index]['component_id'],'current_track':objects[index]['track_id'],
                    'previous_track':key,'overlap':overlap,'recurrence_hits':hits,
                    'mutually_unique':unique,'alternative_to_global_assignment':alternative}
                edges.append(edge)
                if alternative:
                    alternatives.append(edge | {'current_object':objects[index],
                        'current_centered_shape':current[index].tolist(),
                        'previous_centered_shape':previous[key][0].tolist()})
        captured.update(association_called=True,motion_valid=bool(v['motion_valid']),
            eligible_current=sum(o.get('sensor_frame_hits',0)>0 for o in objects),
            eligible_previous_under_rejected_motion=len(previous),
            native_pairs_under_rejected_motion=len(previous)*len(current),
            passing_pairs=len(edges),mutually_unique_pairs=len(fallback),
            alternative_pairs=len(alternatives),edges=edges,alternatives=alternatives)
    @functools.wraps(original)
    def observed(*args,**kwargs):
        previous_profile=sys.getprofile()
        sys.setprofile(profile)
        try:
            return original(*args,**kwargs)
        finally:
            sys.setprofile(previous_profile)
    detector._associate=observed


summaries={}
for case in plan['cases']:
    name=case['name']
    bag=Path(case['path'])
    if digest(bag/'metadata.yaml')!=case['metadata_sha256']:
        raise ValueError('Bag metadata changed')
    for file in case['files']:
        if (bag/file['name']).stat().st_size!=file['bytes']:
            raise ValueError('Bag file size changed')
    detector=Detector(config)
    captured={}
    if variant=='candidate':
        instrument(detector,captured)
    counts=Counter()
    statuses=Counter()
    reasons=Counter()
    ingestion={}
    previous_stamp=None
    previous_alarm=False
    seen=set()
    started=time.perf_counter()
    count=0
    limit=plan.get('max_selected_frames')
    with gzip.open(out/f'{name}.jsonl.gz','wt',compresslevel=1) as rows, gzip.open(out/f'{name}-trace.jsonl.gz','wt',compresslevel=1) as traces, gzip.open(out/f'{name}-alternatives.jsonl.gz','wt',compresslevel=1) as alternatives:
        for scan in iter_bag(bag,config,every=case['stride'],max_frames=limit,diagnostics=ingestion):
            if scan.index!=count*case['stride'] or scan.measurement_timestamp_ns in seen:
                raise ValueError('Changed selection/duplicate acquisition')
            seen.add(scan.measurement_timestamp_ns)
            signature=input_digest(scan)
            captured.clear()
            row=detector.process(scan.points,scan.timestamp_s,scan.point_times,point_attributes=scan.attributes)
            row.update(frame=scan.index,selected_index=count,measurement_timestamp_ns=scan.measurement_timestamp_ns,
                record_timestamp_ns=scan.record_timestamp_ns,source_scan_id=f'{scan.topic}:{scan.frame_id}:{scan.measurement_timestamp_ns}',input_sha256=signature)
            rows.write(json.dumps(row,allow_nan=False)+'\n')
            trace=dict(captured)
            for exposure in trace.pop('alternatives',[]):
                alternatives.write(json.dumps({'frame':scan.index,'measurement_timestamp_ns':scan.measurement_timestamp_ns,
                    'status':row['status'],'motion':row.get('motion'),'geometry':row.get('geometry'),**exposure},allow_nan=False)+'\n')
            trace.update(frame=scan.index,selected_index=count,measurement_timestamp_ns=scan.measurement_timestamp_ns,
                input_sha256=signature,association_called=captured.get('association_called',False))
            traces.write(json.dumps(trace,allow_nan=False)+'\n')
            for key in ['native_pairs_under_rejected_motion','passing_pairs','mutually_unique_pairs','alternative_pairs']:
                counts[key]+=captured.get(key,0)
            motion_valid=bool(row.get('motion',{}).get('valid',False))
            counts['rejected_motion_frames']+=not motion_valid
            if not motion_valid:
                reasons[row.get('motion',{}).get('reason','unavailable')]+=1
            counts['frames_with_native_pairs_under_rejected_motion']+=captured.get('native_pairs_under_rejected_motion',0)>0
            counts['frames_with_alternative_correspondence']+=captured.get('alternative_pairs',0)>0
            alarm=any(o.get('intersection_confirmed',False) for o in row['objects'])
            delta=scan.measurement_timestamp_ns-previous_stamp if previous_stamp is not None else None
            if delta is not None and delta<=0:
                raise ValueError('Non-increasing original acquisition time')
            gap=delta is not None and delta>round(plan['episode_max_gap_s']*1e9)
            counts['alarm_frames']+=alarm
            counts['alarm_episodes']+=alarm and (previous_stamp is None or gap or not previous_alarm)
            counts['gap_resets']+=bool(row.get('gap_reset'))
            statuses[row['status']]+=1
            previous_stamp=scan.measurement_timestamp_ns
            previous_alarm=alarm
            count+=1
            if count%100==0:
                rows.flush(); traces.flush(); alternatives.flush()
                print(json.dumps({'case':name,'variant':variant,'frames':count}),flush=True)
    expected=min(case['expected_selected_frames'],limit or case['expected_selected_frames'])
    if count!=expected:
        raise ValueError('Incomplete configured selection')
    if limit is None and ingestion['source_messages']!=case['metadata_message_count']:
        raise ValueError('Incomplete source scan enumeration')
    summaries[name]={'frames':count,'counts':dict(counts),'status_frames':dict(statuses),
        'rejected_motion_reasons':dict(reasons),'ingestion':ingestion,'wall_s':time.perf_counter()-started,
        'rows_sha256':digest(out/f'{name}.jsonl.gz')}
    write_json(out/'summaries.json',summaries)
    print(json.dumps({'completed':name,'variant':variant,**summaries[name]}),flush=True)
write_json(out/'completion.json',{'complete':True,'cases':len(summaries),'frames':sum(s['frames'] for s in summaries.values())})
