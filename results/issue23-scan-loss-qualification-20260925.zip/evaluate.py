"""Separate evaluation of completed paired real scan-loss experiments."""
from collections import Counter
import gzip
import itertools
import json
from pathlib import Path
import sys

root=Path(sys.argv[1])
plan=json.loads((root/'experiment.json').read_text())
contract=json.loads((root/'audit-contract.json').read_text())
out=Path(plan['output'])
ignored=set(contract['ignored_elapsed_fields'])
allowed_row=set(contract['allowed_decision_fields'])
allowed_object=set(contract['allowed_local_evidence_fields'])
violations=[]
reports={}
all_changes=[]
all_additions=[]
all_losses=[]
unique_inputs=set()
for variant in plan['variant_order']:
    complete=json.loads((out/variant/'completion.json').read_text())
    if not complete['complete'] or complete['cases']!=len(plan['cases']):
        violations.append({'kind':'incomplete_variant','variant':variant})
summaries={v:json.loads((out/v/'summaries.json').read_text()) for v in plan['variant_order']}
for case in plan['cases']:
    name=case['name']
    totals=Counter()
    trace_counts=Counter()
    traces={}
    opportunities=[]
    with gzip.open(out/'candidate'/f'{name}-trace.jsonl.gz','rt') as stream:
        for line in stream:
            row=json.loads(line)
            if row['frame'] in traces:
                violations.append({'case':name,'kind':'duplicate_trace_frame'})
            traces[row['frame']]=row
            for key in ['native_pairs_under_rejected_motion','passing_pairs','mutually_unique_pairs','alternative_pairs']:
                trace_counts[key]+=row.get(key,0)
            if row.get('native_pairs_under_rejected_motion',0):
                opportunities.append(row)
            if row.get('motion_valid') and row.get('native_pairs_under_rejected_motion',0):
                violations.append({'case':name,'frame':row['frame'],'kind':'fallback_observed_under_valid_motion'})
    with gzip.open(out/'baseline'/f'{name}.jsonl.gz','rt') as a,gzip.open(out/'candidate'/f'{name}.jsonl.gz','rt') as b:
        for index,pair in enumerate(itertools.zip_longest(a,b)):
            if None in pair:
                violations.append({'case':name,'kind':'paired_length_mismatch'}); break
            before,after=map(json.loads,pair)
            frame=before['frame']
            totals['paired_frames']+=1
            unique_inputs.add((case['metadata_sha256'],frame))
            if frame!=index*case['stride'] or before['selected_index']!=index:
                violations.append({'case':name,'frame':frame,'kind':'selection_mismatch'})
            trace=traces.get(frame)
            if trace is None or trace['measurement_timestamp_ns']!=before['measurement_timestamp_ns'] or trace['input_sha256']!=before['input_sha256']:
                violations.append({'case':name,'frame':frame,'kind':'trace_acquisition_mismatch'})
            if not after.get('motion',{}).get('valid',False):
                totals['invalid_motion_frames']+=1
                totals['registration_rejected_frames']+=after.get('motion',{}).get('reason')=='registration_rejected'
                if trace is not None and trace.get('association_called'):
                    current=trace.get('eligible_current',0)>0
                    previous=trace.get('eligible_previous_under_rejected_motion',0)>0
                    category=('both' if current and previous else 'current_only' if current
                              else 'previous_only' if previous else 'neither')
                    totals['invalid_motion_eligibility_'+category]+=1
                else:
                    totals['invalid_motion_association_not_called']+=1
            row_fields=[k for k in set(before)|set(after) if k not in ignored and k!='objects' and before.get(k)!=after.get(k)]
            unexpected=[k for k in row_fields if k not in allowed_row]
            if 'pipeline' in unexpected:
                association=before['pipeline'].get('association',{})
                if association.get('confirmed')==sum(bool(o.get('confirmed',False)) for o in before['objects']):
                    expected=before['pipeline'] | {'association':association | {'confirmed':sum(bool(o.get('confirmed',False)) for o in after['objects'])}}
                    if after['pipeline']==expected:
                        unexpected.remove('pipeline')
            if unexpected:
                violations.append({'case':name,'frame':frame,'kind':'unexpected_row_fields','fields':unexpected})
            old_objects,new_objects=before['objects'],after['objects']
            if [(o['component_id'],o['track_id']) for o in old_objects]!=[(o['component_id'],o['track_id']) for o in new_objects]:
                violations.append({'case':name,'frame':frame,'kind':'global_identity_or_components_changed'}); continue
            object_changes=[]
            for old,new in zip(old_objects,new_objects):
                fields=[k for k in set(old)|set(new) if old.get(k)!=new.get(k)]
                unexpected_object=[k for k in fields if k not in allowed_object]
                if unexpected_object:
                    violations.append({'case':name,'frame':frame,'component_id':old['component_id'],'kind':'unexpected_component_fields','fields':unexpected_object})
                if fields:
                    object_changes.append({'component_id':old['component_id'],'track_id':old['track_id'],
                        'fields':{k:{'before':old.get(k),'after':new.get(k)} for k in fields}})
                for key in ['presence_confirmed','intersection_confirmed']:
                    if new.get(key,False) and not old.get(key,False):
                        totals['additional_'+key]+=1
                        all_additions.append({'case':name,'frame':frame,'field':key,'before':old,'after':new,
                            'geometry':after.get('geometry'),'motion':after.get('motion'),'input_sha256':after['input_sha256'],'trace':trace})
                    if old.get(key,False) and not new.get(key,False):
                        totals['lost_'+key]+=1
                        all_losses.append({'case':name,'frame':frame,'field':key,'before':old,'after':new})
            base_alarm=any(o.get('intersection_confirmed',False) for o in old_objects)
            candidate_alarm=any(o.get('intersection_confirmed',False) for o in new_objects)
            totals['additional_alarm_frames']+=candidate_alarm and not base_alarm
            if row_fields or object_changes:
                totals['changed_frames']+=1
                all_changes.append({'case':name,'frame':frame,
                    'row_fields':{k:{'before':before.get(k),'after':after.get(k)} for k in row_fields},'objects':object_changes})
    if totals['paired_frames']!=case['expected_selected_frames'] or len(traces)!=case['expected_selected_frames']:
        violations.append({'case':name,'kind':'missing_selected_acquisitions'})
    candidate_counts=summaries['candidate'][name]['counts']
    for key,count in trace_counts.items():
        if count!=candidate_counts[key]:
            violations.append({'case':name,'kind':'trace_counter_mismatch','field':key})
    with gzip.open(out/'candidate'/f'{name}-alternatives.jsonl.gz','rt') as stream:
        exposures=[json.loads(line) for line in stream]
    if len(exposures)!=trace_counts['alternative_pairs']:
        violations.append({'case':name,'kind':'missing_alternative_geometry'})
    reports[name]={'stride':case['stride'],'totals':dict(totals),'fallback_counts':dict(trace_counts),
        'baseline':summaries['baseline'][name],'candidate':summaries['candidate'][name],
        'all_pair_opportunity_frames':opportunities,'alternative_exposures':exposures}
if all_losses:
    violations.append({'kind':'lost_baseline_confirmations','count':len(all_losses)})
additional=sum(r['totals'].get('additional_presence_confirmed',0)+r['totals'].get('additional_intersection_confirmed',0) for r in reports.values())
alternatives=sum(r['fallback_counts']['alternative_pairs'] for r in reports.values())
pairs=sum(r['fallback_counts']['native_pairs_under_rejected_motion'] for r in reports.values())
if violations:
    decision='INVALID: paired scientific or input invariants failed; no qualification claim.'
elif additional:
    decision='REJECT DIRECT ADOPTION: additional confirmations occurred on the declared-negative streams.'
elif alternatives==0:
    decision='INCONCLUSIVE: no added confirmations, but no alternative-to-global-assignment shape recurrence was exercised. Do not claim fallback safety.'
else:
    decision='NO ADDED CONFIRMATIONS IN THIS SCENARIO: alternative recurrence was exercised; not field safety, primary improvement or promotion.'
report={'hypothesis':plan['hypothesis'],'criterion':plan['criterion'],'valid':not violations,'violations':violations,
    'paired_processed_frames':sum(r['totals']['paired_frames'] for r in reports.values()),'distinct_original_acquisitions':len(unique_inputs),
    'native_pairs_under_rejected_motion':pairs,'alternative_correspondence_pairs':alternatives,
    'additional_presence_components':sum(r['totals'].get('additional_presence_confirmed',0) for r in reports.values()),
    'additional_intersection_components':sum(r['totals'].get('additional_intersection_confirmed',0) for r in reports.values()),
    'additional_alarm_frames':sum(r['totals']['additional_alarm_frames'] for r in reports.values()),
    'decision':decision,'promotion':False,'cases':reports,'all_changes':all_changes,
    'all_additions':all_additions,'all_losses':all_losses,'limits':plan['limits']+['Cases overlap in underlying acquisitions; summed processed frames are not independent events.']}
(root/'evaluation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['valid','violations','paired_processed_frames','distinct_original_acquisitions','native_pairs_under_rejected_motion','alternative_correspondence_pairs','additional_presence_components','additional_intersection_components','additional_alarm_frames','decision']},indent=2))
if violations:
    raise SystemExit('Paired experiment validity failed')
