"""Execute the two configured real-detector variants serially and retain their console logs."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

recipe=Path(sys.argv[1]).resolve()
plan=json.loads(recipe.read_text())
runner=recipe.parent/'replay.py'
out=Path(plan['output'])
out.mkdir(parents=True,exist_ok=False)
records=[]
for variant in plan['variant_order']:
    package=Path(plan['variants'][variant]['package'])
    env=os.environ | plan['thread_environment'] | {'PYTHONPATH':str(package.parent)}
    command=[sys.executable,str(runner),str(recipe),variant]
    started=time.time()
    print(f'Starting actual {variant}: {len(plan["cases"])} fixed scan-loss cases',flush=True)
    with (out/f'{variant}.log').open('x') as log:
        result=subprocess.run(command,cwd=package.parent,env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append({'variant':variant,'command':command,'cwd':str(package.parent),
        'started_unix_s':started,'finished_unix_s':time.time(),'returncode':result.returncode})
    (out/'launch.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records[-1]),flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
