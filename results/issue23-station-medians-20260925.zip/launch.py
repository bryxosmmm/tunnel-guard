import json
import os
from pathlib import Path
import subprocess
import sys
import time
root=Path('build/issue23-station-medians')
plan=json.loads((root/'paired-plan.json').read_text())
results=[]
for path in plan['plans']:
    recipe=json.loads(Path(path).read_text())
    env=os.environ.copy();env.update(recipe['thread_environment']);env['PYTHONPATH']=recipe['source_root']
    started=time.perf_counter()
    with (root/(Path(path).stem+'.log')).open('w') as log:
        result=subprocess.run([sys.executable,plan['runner'],path],env=env,stdout=log,stderr=subprocess.STDOUT)
    item={'plan':path,'variant':recipe['variant'],'returncode':result.returncode,'wall_s':time.perf_counter()-started}
    results.append(item);(root/'launch-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(item),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
