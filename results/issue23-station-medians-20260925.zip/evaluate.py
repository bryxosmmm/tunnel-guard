import json
from collections import defaultdict
from pathlib import Path
import numpy as np

root=Path('build/issue23-station-medians')
plan=json.loads((root/'paired-plan.json').read_text())
launch=json.loads((root/'launch-results.json').read_text())
if len(launch)!=len(plan['plans']) or any(item['returncode'] for item in launch):
    raise ValueError('Not every declared replay completed')
signatures={}
timings=defaultdict(lambda:defaultdict(list))
run_rows=[]
for path in plan['plans']:
    recipe=json.loads(Path(path).read_text());out=Path(recipe['output'])
    if json.loads((out/'experiment.json').read_text())!=recipe:
        raise ValueError('Executed recipe differs from fixed plan')
    total_elapsed=total_cpu=0.0
    for entry in recipe['recordings']:
        name=Path(entry['path']).name
        rows=json.loads((out/(name+'-measurements.json')).read_text())
        if len(rows)!=recipe['frames_per_recording'] or [r['frame'] for r in rows]!=list(range(len(rows))):
            raise ValueError('Incomplete measurements')
        identity=[(r['measurement_timestamp_ns'],r['scientific_sha256']) for r in rows]
        if name in signatures and signatures[name]!=identity:
            raise ValueError('Scientific outputs differ across paired runs')
        signatures[name]=identity
        timed=rows[plan['warmup_frames']:]
        elapsed=sum(r['elapsed_s'] for r in timed);cpu=sum(r['cpu_s'] for r in timed)
        total_elapsed+=elapsed;total_cpu+=cpu
        timings[name][recipe['variant']].append({'elapsed_s':elapsed,'cpu_s':cpu,'p50_s':float(np.median([r['elapsed_s'] for r in timed])),'p95_s':float(np.quantile([r['elapsed_s'] for r in timed],.95))})
    timings['combined'][recipe['variant']].append({'elapsed_s':total_elapsed,'cpu_s':total_cpu})
    run_rows.append({'plan':path,'variant':recipe['variant'],'processing_elapsed_s':total_elapsed,'processing_cpu_s':total_cpu})
comparisons={}
for name,variants in timings.items():
    a=[r['elapsed_s'] for r in variants['baseline']];b=[r['elapsed_s'] for r in variants['candidate']]
    ac=[r['cpu_s'] for r in variants['baseline']];bc=[r['cpu_s'] for r in variants['candidate']]
    comparisons[name]={'runs':dict(variants),'elapsed_ratio_of_means':float(np.mean(b)/np.mean(a)),
        'cpu_ratio_of_means':float(np.mean(bc)/np.mean(ac)),
        'every_candidate_elapsed_below_every_baseline':max(b)<min(a)}
report={'actual_processed_acquisitions':sum(len(v) for v in signatures.values())*len(plan['plans']),
        'distinct_acquisitions':sum(len(v) for v in signatures.values()),'scientific_identity':True,
        'run_order':run_rows,'comparisons':comparisons,
        'limits':['Only two100frame prefixes, two executions per variant, not independent detection events.',
                  'Timing is unprofiled local Detector.process, not full harness runtime or live latency.',
                  'No primary-metric improvement or production promotion claimed; full panel not rerun.']}
(root/'evaluation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
