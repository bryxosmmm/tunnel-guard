import hashlib
import json
from pathlib import Path
import shutil
import sys
from scripts.benchmark_issue23 import load,support_probe
import tunnel_guard.detector as module
from tunnel_guard import _native
from tunnel_guard.run import capture_native_sources,environment,write_json

plan=load(sys.argv[1]);source=Path(plan['source_root'])
if Path(module.__file__).resolve().parent!=source/'tunnel_guard': raise ValueError('Wrong imported source')
for name,expected in plan['source_sha256'].items():
    if hashlib.sha256((source/name).read_bytes()).hexdigest()!=expected: raise ValueError('Source changed')
if hashlib.sha256(Path(plan['config']).read_bytes()).hexdigest()!=plan['config_sha256']: raise ValueError('Config changed')
if hashlib.sha256(Path(_native.__file__).read_bytes()).hexdigest()!=plan['native_sha256']: raise ValueError('Native changed')
out=Path(plan['output']);out.mkdir(parents=True,exist_ok=False)
write_json(out/'experiment.json',plan);write_json(out/'manifest.json',environment())
shutil.copy2(__file__,out/'probe.py');capture_native_sources(out/'source')
probes=support_probe(load(plan['fixed_recipe']),module.load_config(plan['config']),out)
changes=[]
for entry in probes:
    frame=entry['frame'];old=load(Path(plan['reference_root'])/f'probe-{frame}.json');new=load(out/f'probe-{frame}.json')
    fields=[k for k in old.keys()|new.keys() if k not in {'processing_s','motion_s','mounting_observation_s'} and old.get(k)!=new.get(k)]
    if fields: changes.append({'frame':frame,'fields':fields})
report={'scans':len(probes),'scientific_changes':changes,'support_membership_identical':sum(p['membership_equal'] for p in probes),'probes':probes,'limits':['Fresh-state support scans, not temporal full-panel acceptance.','Concurrent correctness qualification: no timing claim.']}
write_json(out/'evaluation.json',report);print(json.dumps(report,indent=2))
if len(probes)!=plan['expected_scans'] or changes or not all(p['membership_equal'] for p in probes): raise ValueError('Actual scan outputs changed')
