"""Describe saved actual output gates; source attribution is not exhaustive field ground truth."""
from collections import Counter
import csv
import gzip
import json
from pathlib import Path
import sys

plan = json.loads(Path(sys.argv[1]).read_text())
config = json.loads(Path(plan['detector_config']).read_text())
events = json.loads(Path(plan['attribution_reference']).read_text())
needed = {r['frame'] for event in plan['focus_events'] for r in events[str(event)]}
frames = {}
with gzip.open(plan['best_rows'], 'rt') as stream:
    for line in stream:
        row = json.loads(line)
        if row['frame'] in needed:
            frames[row['frame']] = row
        if row['frame'] >= max(needed):
            break
records = []
summaries = {}
for event in plan['focus_events']:
    rows = events[str(event)]
    first_confirmation = next((r['frame'] for r in rows if any(o['intersection_confirmed'] for o in r['components'])), None)
    for row in rows:
        objects = row['components']
        eligible = [o for o in objects if o['path_relation'] == 'intersecting'
                    and o['certified_unexplained_voxels'] >= config['claim_min_support_voxels']
                    and o['support_voxels'] >= config['evidence_min_points']]
        if any(o['intersection_confirmed'] for o in objects):
            stage = 'intersection_confirmed'
        elif not objects:
            stage = 'no_majority_attributed_component'
        elif not any(o['path_relation'] == 'intersecting' for o in objects):
            stage = 'no_intersecting_component'
        elif not eligible:
            stage = 'insufficient_current_unexplained_support'
        elif any(o.get('sensor_frame_hits', 0) >= config['confirmation_hits'] for o in eligible):
            stage = 'local_hits_ready_but_confirmation_not_enabled'
        elif any(o.get('sensor_frame_shape_overlap') is not None for o in eligible):
            stage = 'shape_overlap_below_configured_gate'
        else:
            stage = 'no_comparable_previous_eligible_shape'
        records.append({'event': event, 'frame': row['frame'], 'source_forward_m': row['source_forward_m'],
            'motion_valid': frames[row['frame']]['motion']['valid'],
            'geometry_valid': frames[row['frame']]['geometry']['valid'],
            'stage': stage, 'after_first_confirmation': first_confirmation is not None and row['frame'] >= first_confirmation,
            'components': [{'component_id': o['component_id'], 'track_id': o['track_id'],
                'path_relation': o['path_relation'], 'support_voxels': o['support_voxels'],
                'certified_unexplained_voxels': o['certified_unexplained_voxels'],
                'interior_structural_voxels': o['interior_structural_voxels'],
                'sensor_frame_hits': o.get('sensor_frame_hits'),
                'sensor_frame_shape_overlap': o.get('sensor_frame_shape_overlap'),
                'intersection_confirmed': o['intersection_confirmed']} for o in objects]})
    selected = [r for r in records if r['event'] == event]
    summaries[event] = {'observed_source_frames': len(rows), 'first_confirmation_frame': first_confirmation,
        'stage_counts': dict(Counter(r['stage'] for r in selected)),
        'after_first_confirmation_stage_counts': dict(Counter(r['stage'] for r in selected if r['after_first_confirmation'])),
        'source_observation_span': [rows[0]['frame'], rows[-1]['frame']]}
result = {'summary': summaries, 'frames': records,
    'limits': ['No-majority-attributed component does not yet distinguish filtering, rejected cluster, or a merged component below the fixed50% attribution gate.',
               'Missing previous eligible shape does not by itself prove a wrong association; inspect actual assignment trace.',
               'Source-observation frames are frozen forensic groups, not a field-recall denominator.',
               'The stage is the observed final gate, not necessarily the physical cause. No threshold changes.']}
Path(plan['stage_output']).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(summaries, indent=2))
