"""Measure additional local-evidence eligibility in saved negative runs; not a candidate detector run."""
import gzip
import json
from pathlib import Path
import sys

plan = json.loads(Path(sys.argv[1]).read_text())
output = {}
for name in plan['negative_recordings']:
    count = 0
    existing_alarm_frames = 0
    additional_frames = []
    additional_components = 0
    for line in gzip.open(Path(plan['reference']) / (name + '.jsonl.gz'), 'rt'):
        row = json.loads(line)
        count += 1
        existing_alarm = any(o['intersection_confirmed'] for o in row['objects'])
        existing_alarm_frames += int(existing_alarm)
        exposed = [o for o in row['objects'] if row['motion']['valid']
            and not o['intersection_confirmed'] and o['path_relation'] == 'intersecting'
            and o.get('sensor_frame_hits', 0) >= plan['confirmation_hits']]
        additional_components += len(exposed)
        if exposed and not existing_alarm:
            additional_frames.append({'frame': row['frame'],
                'measurement_timestamp_ns': row['measurement_timestamp_ns'],
                'components': [{'component_id': o['component_id'], 'track_id': o['track_id'],
                    'sensor_frame_hits': o['sensor_frame_hits'],
                    'sensor_frame_shape_overlap': o['sensor_frame_shape_overlap'],
                    'certified_unexplained_voxels': o['certified_unexplained_voxels']} for o in exposed]})
    output[name] = {'frames': count, 'existing_alarm_frames': existing_alarm_frames,
        'additional_eligible_components': additional_components,
        'additional_alarm_frame_exposure': len(additional_frames), 'exposed_frames': additional_frames}
    print(name + ': ' + str(len(additional_frames)) + ' additional alarm-frame exposures', flush=True)
result = {'hypothesis': 'Removing only the not-motion-valid condition from local confirmation exposes these saved components.',
    'kind': 'offline_existing_evidence_gate_exposure_not_actual_candidate_replay', 'recordings': output,
    'total_additional_alarm_frame_exposure': sum(v['additional_alarm_frame_exposure'] for v in output.values()),
    'limits': ['No production source changed and no candidate execution claimed.',
               'Existing actor/geometry histories reused. This is a rejection screen, not a promotion metric.',
               'Fixed organizer-declared negative panel, not exhaustive point truth or field precision.']}
Path(plan['output']).write_text(json.dumps(result, indent=2) + '\n')
