"""Record actual SciPy assignments during a real detector replay; never change their inputs/results."""
import inspect
import json
from pathlib import Path
import runpy
import sys
import numpy as np
import tunnel_guard.detector as module

recipe_path = Path(sys.argv[1])
plan = json.loads(recipe_path.read_text())
reference = json.loads(Path(plan['attribution_reference']).read_text())
queries = {}
for event in plan['focus_events']:
    previous = []
    for row in reference[str(event)]:
        frame = row['frame']
        if plan['focus_start_frame'] <= frame < plan['max_frames']:
            queries.setdefault(frame, []).append({'event': event,
                'current_components': [o['component_id'] for o in row['components']],
                'previous_tracks': previous})
        if row['components']:
            previous = [o['track_id'] for o in row['components']]
original = module.linear_sum_assignment
trace_path = Path(plan['assignment_trace'])
trace_path.parent.mkdir(parents=True, exist_ok=True)
stream = trace_path.open('x')

def observed_assignment(cost):
    result = original(cost)
    caller = inspect.currentframe().f_back
    try:
        values = caller.f_locals
        detector = values['self']
        frame = detector.frame_number - 1
        if frame not in queries:
            return result
        ids = values['ids']
        objects = values['objects']
        component_columns = {obj['component_id']: i for i, obj in enumerate(objects)}
        assignments = {int(r): int(c) for r, c in zip(*result)}
        for query in queries[frame]:
            target_columns = [component_columns[c] for c in query['current_components'] if c in component_columns]
            chosen_rows = [r for r, c in assignments.items() if c in target_columns and cost[r, c] < 1e6]
            relevant = set(query['previous_tracks']) | {ids[r] for r in chosen_rows}
            records = []
            for track_id in sorted(relevant):
                if track_id not in ids:
                    records.append({'track_id': track_id, 'retained': False})
                    continue
                r = ids.index(track_id)
                c = assignments.get(r)
                assigned = objects[c] if c is not None and c < len(objects) and cost[r, c] < 1e6 else None
                track = detector.tracks[track_id]
                targets = [{'component_id': objects[j]['component_id'],
                    'allowed': bool(values['allowed'][r, j]),
                    'mahalanobis': float(values['mahalanobis'][r, j]),
                    'extent_log_difference': float(values['shape'][r, j]),
                    'cost': float(cost[r, j]),
                    'world_residual': values['residual'][r, j].tolist()} for j in target_columns]
                records.append({'track_id': track_id, 'retained': True,
                    'previous_local_hits': track.get('local_hits'),
                    'previous_local_frame': track.get('local_frame'),
                    'assigned_component': assigned['component_id'] if assigned else None,
                    'assigned_center': assigned['center'] if assigned else None,
                    'assigned_cost': float(cost[r, c]) if assigned else None,
                    'targets': targets})
            stream.write(json.dumps({'frame': frame, 'event': query['event'],
                'current_components': query['current_components'], 'tracks': records,
                'motion_valid': bool(values['motion']['valid']),
                'pose_sigma': float(values['pose_sigma']),
                'mahalanobis_gate': detector.config['tracking_mahalanobis_gate'],
                'extent_log_gate': detector.config['tracking_extent_log_gate']}, allow_nan=False) + '\n')
        stream.flush()
        return result
    finally:
        del caller

module.linear_sum_assignment = observed_assignment
try:
    runpy.run_path(plan['replay_runner'], run_name='__main__')
finally:
    module.linear_sum_assignment = original
    stream.close()
