import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path
import numpy as np
from scipy.optimize import linprog

root=Path('build/issue23-rail-fit-rejections')
plan=json.loads((root/'feasibility.json').read_text())
cfg=json.loads(Path(plan['config']).read_text())
with gzip.open(plan['input'],'rt') as f:
    rows=[json.loads(line) for line in f]
results=[]
for row in rows:
    retained={a['fit']['window_center_m'] for a in row['retained']}
    for a in row['attempts']:
        if not a['failed_guard']:
            continue
        if a['rank'] != 3 or a['fit_representatives_xy'] is None:
            raise ValueError('Observed case lacks complete rank-three measured model')
        points=np.asarray(a['fit_representatives_xy'])
        design=np.column_stack((points[:,0]-a['window_center_m'],np.ones(len(points)),np.asarray(a['fit_sides'])/2))
        y=points[:,1]
        bounds=[(-cfg['rail_max_heading'],cfg['rail_max_heading']),
                (a['expected_center_m']-a['allowed_center_deviation_m'],a['expected_center_m']+a['allowed_center_deviation_m']),
                (cfg['rail_gauge_m']-cfg['rail_gauge_tolerance_m'],cfg['rail_gauge_m']+cfg['rail_gauge_tolerance_m']), (0,None)]
        matrix=np.concatenate((np.column_stack((design,-np.ones(len(points)))),np.column_stack((-design,-np.ones(len(points))))))
        solved=linprog([0,0,0,1],A_ub=matrix,b_ub=np.concatenate((y,-y)),bounds=bounds,method='highs')
        record={'frame':row['frame'],'window_center_m':a['window_center_m'],'retained':a['window_center_m'] in retained,'original_first_failed_guard':a['failed_guard'],'source_return_line':a['return_line'],'points':len(points),'solver_success':bool(solved.success),'solver_status':int(solved.status),'solver_message':solved.message}
        if solved.success:
            slope,center,gauge,r=map(float,solved.x)
            residual=float(np.max(np.abs(design@solved.x[:3]-y)))
            checks={'heading':abs(slope)<=cfg['rail_max_heading'], 'center':abs(center-a['expected_center_m'])<=a['allowed_center_deviation_m'], 'gauge':abs(gauge-cfg['rail_gauge_m'])<=cfg['rail_gauge_tolerance_m'], 'residual':residual<=cfg['rail_half_width_m']/2}
            record.update(coefficients=[slope,center,gauge],solver_residual_m=r,recomputed_max_residual_m=residual,original_max_residual_m=float(np.max(np.abs(design@np.asarray(a['fit_coefficients'])-y))),guards=checks,strictly_feasible=all(checks.values()))
        results.append(record)
report={'plan':plan,'input_sha256':hashlib.sha256(Path(plan['input']).read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(Path(plan['config']).read_bytes()).hexdigest(),'attempts':sum(len(r['attempts']) for r in rows),'failed_attempts':len(results),'first_failed_guards':dict(Counter(a['failed_guard'] for r in rows for a in r['attempts'] if a['failed_guard'])),'retained_failed_guards':dict(Counter(a['fit']['failed_guard'] for r in rows for a in r['retained'] if a['fit']['failed_guard'])),'strictly_feasible':sum(r.get('strictly_feasible',False) for r in results),'retained_strictly_feasible':sum(r['retained'] and r.get('strictly_feasible',False) for r in results),'results':results}
Path(plan['output']).write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'results','plan'}},indent=2))
