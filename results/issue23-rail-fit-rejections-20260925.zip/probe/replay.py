import gzip
import hashlib
import json
import shutil
import sys
from collections import Counter
from pathlib import Path
import numpy as np
from scripts.benchmark_issue23 import load, support_probe
from tunnel_guard.detector import Detector, load_config
from tunnel_guard.geometry import TrackGeometry, refine_rail_pair
from tunnel_guard.run import capture_native_sources, environment, write_json

root = Path('build/issue23-rail-fit-rejections')
recipe = load(root/'experiment.json')
for path, expected in [(recipe['config'],recipe['config_sha256']),('tunnel_guard/geometry.py',recipe['geometry_sha256']),('tunnel_guard/_native.cpython-312-darwin.so',recipe['native_sha256'])]:
    if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=expected:
        raise ValueError('Frozen detector changed')
out = Path(recipe['output'])
out.mkdir(parents=True,exist_ok=False)
capture_native_sources(out)
shutil.copy2(recipe['config'],out/'detector.json')
shutil.copy2(root/'experiment.json',out/'experiment.json')
shutil.copy2(__file__,out/'replay.py')
write_json(out/'manifest.json',environment())
current = None
fits = {}
evidence = []

def observe(frame,event,result):
    global current, fits
    if event=='call' and frame.f_code is Detector.process.__code__:
        current = int(frame.f_back.f_locals['entry']['frame'])
        fits = {}
    if event!='return':
        return
    if frame.f_code is refine_rail_pair.__code__:
        local = frame.f_locals
        caller = frame.f_back.f_locals
        accepted = result is not None and abs(result[0]-caller['expected'])<=caller['allowed']
        item = {'window_center_m':float(local['x']), 'refinement_returned':result is not None,
                'refinement_accepted':bool(accepted), 'input_heading_slope':float(caller['slope']),
                'expected_center_m':float(caller['expected']), 'allowed_center_deviation_m':float(caller['allowed']),
                'result':list(result) if result is not None else None,
                'fit_representatives_xy':local['a'].tolist() if 'a' in local else None,
                'fit_sides':list(local['sides']) if 'a' in local else None}
        item['return_line'] = frame.f_lineno
        item['iteration'] = int(local['_']) if isinstance(local.get('_'), (int, np.integer)) else None
        item['rank'] = int(local['rank']) if 'rank' in local else None
        item['fit_coefficients'] = local['fit'].tolist() if 'fit' in local else None
        item['head_count'] = len(local['head']) if 'head' in local else None
        item['head_span_m'] = float(np.ptp(local['head'][:,0])) if len(local.get('head',[])) else None
        item['failed_guard'] = None
        if result is None:
            if frame.f_lineno == 156:
                item['failed_guard'] = 'head_count' if len(local['head']) < 2 else 'head_span'
            elif frame.f_lineno == 165:
                item['failed_guard'] = 'design_rank'
            elif frame.f_lineno == 170:
                c = local['cfg']
                item['max_residual_m'] = float(np.max(np.abs(local['design'] @ local['fit'] - local['a'][:,1])))
                item['violated_guards'] = [name for name,bad in [('heading',abs(local['slope']) > c['rail_max_heading']),('gauge',abs(local['gauge']-c['rail_gauge_m']) > c['rail_gauge_tolerance_m']),('residual',item['max_residual_m'] > c['rail_half_width_m']/2)] if bad]
                item['failed_guard'] = item['violated_guards'][0]
            else:
                raise ValueError('Unmapped rejection source location')
        elif not accepted:
            item['failed_guard'] = 'center_prior'
        fits[(id(caller['self']),float(local['x']))] = item
    elif frame.f_code is TrackGeometry._rail_profile.__code__:
        geometry = frame.f_locals['self']
        retained = []
        for anchor,diagnostic in zip(geometry.rail_anchors,geometry.rail_support_diagnostics):
            if float(anchor[0])!=diagnostic['x_m']:
                raise ValueError('Retained diagnostic prefix no longer aligns')
            fit = fits[(id(geometry),diagnostic['window_center_m'])]
            expected_heading = fit['result'][2] if fit['refinement_accepted'] else fit['input_heading_slope']
            if diagnostic['heading_slope']!=expected_heading:
                raise ValueError('Observed heading origin not accounted for')
            retained.append({'anchor':anchor.tolist(),'diagnostic':diagnostic,'fit':fit})
        if len(retained)!=len(geometry.rail_anchors):
            raise ValueError('Missing retained-anchor diagnostics')
        evidence.append({'frame':current,'retained':retained,'attempts':[v for (identity,x),v in fits.items() if identity==id(geometry)],'discarded_trailing_diagnostics':len(geometry.rail_support_diagnostics)-len(retained)})

sys.setprofile(observe)
try:
    probes = support_probe(load(recipe['fixed_recipe']),load_config(recipe['config']),out)
finally:
    sys.setprofile(None)
with gzip.open(out/'heading-origin.jsonl.gz','wt') as stream:
    for item in evidence:
        stream.write(json.dumps(item,allow_nan=False)+'\n')
counts = Counter()
for item in evidence:
    for retained in item['retained']:
        counts['retained_anchors']+=1
        counts['accepted_pair_fit' if retained['fit']['refinement_accepted'] else 'inherited_heading']+=1
elapsed={'processing_s','motion_s','mounting_observation_s'}
changes=[]
for probe in probes:
    old=load(Path(recipe['reference_root'])/f"probe-{probe['frame']}.json")
    new=load(out/f"probe-{probe['frame']}.json")
    differing=[key for key in old.keys()|new.keys() if key not in elapsed and old.get(key)!=new.get(key)]
    if differing: changes.append({'frame':probe['frame'],'fields':differing})
report={'scans':len(probes),'geometry_observations':len(evidence),'scientific_changes':changes,
        'counts':dict(counts),'limits':recipe['limits']}
write_json(out/'evaluation.json',report)
print(json.dumps(report,indent=2))
if len(probes)!=recipe['expected_scans'] or changes:
    raise ValueError('Actual observation did not preserve the fixed probe outputs')
