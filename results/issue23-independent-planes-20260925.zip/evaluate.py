"""Descriptive evaluation of unchanged actual detector observations, not a candidate benchmark."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import sys
root = Path(sys.argv[1]); outputs = sys.argv[2:]
targets = json.loads((root/'targets.json').read_text())
point_owners = {}
if 'positive' in outputs:
    positive_plan = json.loads((root/'positive.json').read_text())
    path = Path(positive_plan['point_attribution'])
    if hashlib.sha256(path.read_bytes()).hexdigest() != positive_plan['point_attribution_sha256']:
        raise ValueError('Frozen original-return attribution changed')
    with gzip.open(path,'rt') as stream:
        point_owners = json.load(stream)
counts = defaultdict(Counter); records = {}; exposures = []; foreground = []
for output in outputs:
    folder = root/output
    completion = json.loads((folder/'completion.json').read_text())
    if not completion['complete']:
        raise ValueError('Incomplete observation stage')
    for name, summary in completion['recordings'].items():
        if name in records or not summary['scientific_identity']:
            raise ValueError('Duplicate recording or failed unchanged-output requirement')
        records[name] = summary; seen = set()
        with gzip.open(folder/(name+'-support.jsonl.gz'),'rt') as stream:
            for line in stream:
                item = json.loads(line); frame = item['frame']
                if frame in seen:
                    raise ValueError('Duplicate target frame')
                seen.add(frame)
                expected = targets.get(name,{}).get(str(frame),{})
                if {str(r['component_id']):r['attribution'] for r in item['records']} != expected:
                    raise ValueError('Target attribution mismatch')
                flags = defaultdict(list); raw_flags = defaultdict(list); fg_frame = defaultdict(Counter)
                for record in item['records']:
                    n = record['certified_queries']
                    mask = record['background_explained']; reliable = record['nearest_fit_normal_reliable']
                    excluded = record['excluded_from_fit']
                    if not len(mask)==len(reliable)==len(excluded)==n or not all(excluded):
                        raise ValueError('Query count or seed-exclusion mismatch')
                    qualified = [bool(a and b) for a,b in zip(mask,reliable)]
                    if sum(mask)!=record['background_explained_queries'] or sum(qualified)!=record['reliable_background_explained_queries']:
                        raise ValueError('Explanation accounting mismatch')
                    for role in record['attribution']:
                        c = counts[role]
                        c['components'] += 1; c['certified_queries'] += n
                        c['raw_explained_queries'] += sum(mask)
                        c['reliably_explained_queries'] += sum(qualified)
                        c['explained_without_reliable_nearby_normal_queries'] += sum(mask)-sum(qualified)
                        c['components_with_other_fit_seed_eligible_returns'] += record['component_fit_seed_eligible_returns']>0
                        all_raw = bool(n and all(mask)); all_qualified = bool(n and all(qualified))
                        c['all_core_explained_components'] += all_raw
                        c['all_core_reliably_explained_components'] += all_qualified
                        flags[role].append(all_qualified); raw_flags[role].append(all_raw)
                        if role.startswith('synthetic_event_'):
                            event = role.removeprefix('synthetic_event_')
                            owner = set(point_owners[str(frame)][event])
                            indices = record['query_original_return_indices']
                            if len(indices)!=n:
                                raise ValueError('Query source-index count mismatch')
                            owned = [i in owner for i in indices]
                            f = fg_frame[role]
                            f['certified_foreground_queries'] += sum(owned)
                            f['raw_explained_foreground_queries'] += sum(a and b for a,b in zip(mask,owned))
                            f['reliably_explained_foreground_queries'] += sum(a and b for a,b in zip(qualified,owned))
                for role, values in flags.items():
                    counts[role]['confirmed_frames'] += 1
                    counts[role]['all_core_explained_frames'] += all(raw_flags[role])
                    counts[role]['all_core_reliably_explained_frames'] += all(values)
                    if all(values):
                        exposures.append({'recording':name,'frame':frame,'role':role})
                    if role in fg_frame:
                        f = fg_frame[role]
                        counts[role].update(f)
                        if not f['certified_foreground_queries']:
                            counts[role]['confirmed_frames_without_certified_foreground_queries'] += 1
                        if f['certified_foreground_queries'] and f['reliably_explained_foreground_queries']==f['certified_foreground_queries']:
                            counts[role]['frames_all_certified_foreground_reliably_explained'] += 1
                        foreground.append({'frame':frame,'role':role,**f})
        if seen != {int(frame) for frame in targets.get(name,{})}:
            raise ValueError('Incomplete target selection')
        with gzip.open(folder/(name+'-frames.jsonl.gz'),'rt') as stream:
            if sum(1 for line in stream)!=summary['counts']['frames']:
                raise ValueError('Incomplete scientific identity journal')
positive_exposures = [e for e in exposures if e['role'].startswith('synthetic_event_')]
report = {'valid':True,'processed_frames':sum(s['counts']['frames'] for s in records.values()),'recordings':records,
          'counts':{k:dict(v) for k,v in counts.items()},'all_core_reliably_explained_frames':exposures,
          'foreground_return_accounting':foreground,'positive_recording_evaluated':'cloud_with_fake_obj' in records,
          'positive_complete_core_exposures':positive_exposures,
          'decision':('Positive gate not run: no safety or positive retention claim.' if 'cloud_with_fake_obj' not in records else 'Reject blanket reliable-plane suppression: it explains complete retained positive core support.' if positive_exposures else 'No complete positive-core exposure observed; partial foreground support and actual candidate behavior still require review. Not promotion.'),
          'limits':['No classifier or output decision changed; explanation counts are not fewer alarms.',
                    'Fit excludes supported nominal-interior queries, not necessarily all returns of an object.',
                    'Normals belong to nearby fit samples, not directly to the queried foreground point.',
                    'Repeated frames and returns are correlated; no independent field precision/recall estimate.',
                    'Point ownership comes from the unchanged frozen organizer source-return fixture; this audit does not relabel the panel.']}
(root/('evaluation-'+'-'.join(outputs)+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'valid':True,'processed_frames':report['processed_frames'],'counts':report['counts'],'decision':report['decision']},indent=2))
