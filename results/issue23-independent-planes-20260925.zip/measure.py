def measure_local(context, objects, target_ids):
    points, geometry = context['points'], context['geometry']
    cloud_rows, labels, core = context['cluster_rows'], context['labels'], context['core']
    if cloud_rows is None:
        if not module.voxel_unique_at(config, context['reduced_on_grid_m']):
            raise ValueError('Unexpected missing native cluster selection')
        cloud_rows = np.flatnonzero(context['context'])
    cloud = context['cloud']
    if not np.array_equal(points[cloud_rows], cloud):
        raise ValueError('Cluster mapping changed')
    selected_ids = np.asarray([int(key) for key in target_ids], dtype=labels.dtype)
    query_rows = np.flatnonzero(core & np.isin(labels, selected_ids))
    query = cloud[query_rows]
    excluded_from_fit = context['observed'][query_rows] & context['nominal_overlap'][query_rows]
    if not np.all(excluded_from_fit):
        raise ValueError('Certified query not excluded by the actual background seed rule')
    background = geometry.background
    explained = np.zeros(len(query), dtype=bool)
    reliable = np.zeros(len(query), dtype=bool)
    distances = np.full(len(query), np.inf)
    nearest_points = None
    nearest_normals = None
    model = None
    if background is not None:
        model = {'rotation':background.rotation.tolist(),'sample_points':len(background.sample),
                 'patches':[{'plane':p[0].tolist(),'transverse_axis':int(p[1]),
                             'strips':np.asarray(p[2]).tolist(),'kind':p[3]} for p in background.patches]}
        if len(query) and background.patches:
            # Execute the existing model, including observed strips and protrusion protection.
            explained = background.mask(query, np.zeros(len(query), dtype=bool))
            leveled = query @ background.rotation.T
            distances, nearest = background.normal_tree.query(leveled, workers=1)
            reliable = (distances <= background.config['normal_radius_m']) & background.normal_reliable[nearest]
            nearest_points = background.sample[nearest]
            nearest_normals = background.normals[nearest]
    records = []
    for obj in objects:
        cid = obj['component_id']
        if str(cid) not in target_ids:
            continue
        selected = labels[query_rows] == cid
        n = int(selected.sum())
        qualified = explained[selected] & reliable[selected]
        member = labels == cid
        component_points = cloud[member]
        bed, _ = geometry.ground(component_points)
        above_rail = component_points[:,2] - bed - geometry.rail_head_height_m
        seed_eligible = (~(context['observed'][member] & context['nominal_overlap'][member])
                         & (above_rail >= config['background']['min_seed_height_m']))
        record = {'component_id':cid,'attribution':target_ids[str(cid)],'object':obj,
                  'certified_queries':n,'certified_structural_queries':int(context['structural'][query_rows[selected]].sum()),
                  'background_explained_queries':int(explained[selected].sum()),
                  'reliable_background_explained_queries':int(qualified.sum()),
                  'all_certified_queries_reliably_explained':bool(n and qualified.all()),
                  'query_points_detector_frame_m':query[selected].tolist(),
                  'excluded_from_fit':excluded_from_fit[selected].tolist(),
                  'component_fit_seed_eligible_returns':int(seed_eligible.sum()),
                  'background_explained':explained[selected].tolist(),
                  'nearest_fit_normal_reliable':reliable[selected].tolist(),
                  'nearest_fit_sample_distance_m':[float(v) if np.isfinite(v) else None for v in distances[selected]],
                  'nearest_fit_sample_leveled_m':nearest_points[selected].tolist() if nearest_points is not None else None,
                  'nearest_fit_normal_leveled':nearest_normals[selected].tolist() if nearest_normals is not None else None}
        records.append(record)
    return records, model
