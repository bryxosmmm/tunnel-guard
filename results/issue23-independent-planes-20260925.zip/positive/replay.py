"""Actual unchanged replay; measure independently fitted longitudinal surface support."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
from collections import Counter
import numpy as np
import tunnel_guard.detector as module
from tunnel_guard.io import iter_bag
from tunnel_guard import _native
from tunnel_guard.run import capture_native_sources, environment, digest, write_json

plan = json.loads(Path(sys.argv[1]).read_text())
config = module.load_config(plan['detector_config'])
if digest(Path(plan['detector_config'])) != plan['config_sha256']:
    raise ValueError('Configuration changed')
if config['seed'] != plan['seed'] or any(os.environ.get(k) != v for k,v in plan['thread_environment'].items()):
    raise ValueError('Seed/thread environment changed')
for name, expected in plan['source_sha256'].items():
    if digest(Path(name)) != expected:
        raise ValueError('Source changed: '+name)
if digest(Path(_native.__file__)) != plan['native_sha256']:
    raise ValueError('Native binary changed')
out = Path(plan['output'])
out.mkdir(parents=True, exist_ok=False)
write_json(out/'experiment.json', plan)
write_json(out/'detector.json', config)
shutil.copytree('tunnel_guard', out/'source/tunnel_guard', ignore=shutil.ignore_patterns('*.so','__pycache__','.DS_Store'))
capture_native_sources(out/'source')
shutil.copy2(__file__, out/'replay.py')
write_json(out/'manifest.json', environment() | {'command':sys.argv, 'native_sha256':digest(Path(_native.__file__)), 'config_sha256':plan['config_sha256'], 'source_sha256':plan['source_sha256']})
ignored = set(plan['ignored_elapsed_fields'])
targets = json.loads(Path(plan['targets']).read_text())
if digest(Path(plan['targets'])) != plan['targets_sha256']:
    raise ValueError('Target inventory changed')
cluster_code = module.cluster_candidates.__code__
diagnostic_frames = {name:set(frames) for name,frames in plan.get('diagnostic_frames',{}).items()}


def measure_local(context, objects, target_ids):
    points, geometry = context['points'], context['geometry']
    cloud_rows, labels, core = context['cluster_rows'], context['labels'], context['core']
    if cloud_rows is None:
        if not module.voxel_unique_at(config, context['reduced_on_grid_m']):
            raise ValueError('Unexpected missing native cluster selection')
        cloud_rows = np.flatnonzero(context['context'])
    cloud = context['cloud']
    if not np.array_equal(points[cloud_rows], cloud):
        raise ValueError('Cluster mapping changed')
    selected_ids = np.asarray([int(key) for key in target_ids], dtype=labels.dtype)
    query_rows = np.flatnonzero(core & np.isin(labels, selected_ids))
    query = cloud[query_rows]
    excluded_from_fit = context['observed'][query_rows] & context['nominal_overlap'][query_rows]
    if not np.all(excluded_from_fit):
        raise ValueError('Certified query not excluded by the actual background seed rule')
    background = geometry.background
    explained = np.zeros(len(query), dtype=bool)
    reliable = np.zeros(len(query), dtype=bool)
    distances = np.full(len(query), np.inf)
    nearest_points = None
    nearest_normals = None
    model = None
    if background is not None:
        model = {'rotation':background.rotation.tolist(),'sample_points':len(background.sample),
                 'patches':[{'plane':p[0].tolist(),'transverse_axis':int(p[1]),
                             'strips':np.asarray(p[2]).tolist(),'kind':p[3]} for p in background.patches]}
        if len(query) and background.patches:
            # Execute the existing model, including observed strips and protrusion protection.
            explained = background.mask(query, np.zeros(len(query), dtype=bool))
            leveled = query @ background.rotation.T
            distances, nearest = background.normal_tree.query(leveled, workers=1)
            reliable = (distances <= background.config['normal_radius_m']) & background.normal_reliable[nearest]
            nearest_points = background.sample[nearest]
            nearest_normals = background.normals[nearest]
    records = []
    for obj in objects:
        cid = obj['component_id']
        if str(cid) not in target_ids:
            continue
        selected = labels[query_rows] == cid
        n = int(selected.sum())
        qualified = explained[selected] & reliable[selected]
        member = labels == cid
        component_points = cloud[member]
        bed, _ = geometry.ground(component_points)
        above_rail = component_points[:,2] - bed - geometry.rail_head_height_m
        seed_eligible = (~(context['observed'][member] & context['nominal_overlap'][member])
                         & (above_rail >= config['background']['min_seed_height_m']))
        record = {'component_id':cid,'attribution':target_ids[str(cid)],'object':obj,
                  'certified_queries':n,'certified_structural_queries':int(context['structural'][query_rows[selected]].sum()),
                  'background_explained_queries':int(explained[selected].sum()),
                  'reliable_background_explained_queries':int(qualified.sum()),
                  'all_certified_queries_reliably_explained':bool(n and qualified.all()),
                  'query_points_detector_frame_m':query[selected].tolist(),
                  'excluded_from_fit':excluded_from_fit[selected].tolist(),
                  'component_fit_seed_eligible_returns':int(seed_eligible.sum()),
                  'background_explained':explained[selected].tolist(),
                  'nearest_fit_normal_reliable':reliable[selected].tolist(),
                  'nearest_fit_sample_distance_m':[float(v) if np.isfinite(v) else None for v in distances[selected]],
                  'nearest_fit_sample_leveled_m':nearest_points[selected].tolist() if nearest_points is not None else None,
                  'nearest_fit_normal_leveled':nearest_normals[selected].tolist() if nearest_normals is not None else None}
        original_indices = context.get('cluster_original_return_indices')
        if original_indices is None:
            raise ValueError('Missing original-return mapping for positive query')
        record['query_original_return_indices'] = original_indices[query_rows[selected]].tolist()
        records.append(record)
    return records, model


summaries = {}
for entry in plan['recordings']:
    bag = Path(entry['path']); name = bag.name
    if digest(bag/'metadata.yaml') != entry['metadata_sha256']:
        raise ValueError('Bag metadata changed: '+name)
    for file in entry.get('files',entry.get('segments',[])):
        if (bag/file.get('name',file.get('file'))).stat().st_size != file['bytes']:
            raise ValueError('Bag file size changed: '+name)
    detector = module.Detector(config)
    counts = Counter(); started = time.perf_counter(); prior_stamp = None
    reference_path = Path(plan['reference'])/(name+'.jsonl.gz')
    with gzip.open(reference_path,'rt') as reference, gzip.open(out/(name+'-frames.jsonl.gz'),'wt') as frames, gzip.open(out/(name+'-support.jsonl.gz'),'wt') as evidence:
        for scan in iter_bag(bag, config, every=1, max_frames=None):
            if scan.index != counts['frames'] or (prior_stamp is not None and scan.measurement_timestamp_ns <= prior_stamp):
                raise ValueError('Missing/reordered acquisition')
            prior_stamp = scan.measurement_timestamp_ns
            selected = targets.get(name,{}).get(str(scan.index),{})
            context = {}
            def capture(frame,event,arg):
                if event == 'return' and frame.f_code is cluster_code:
                    context.update(frame.f_locals)
            prior_profile = sys.getprofile()
            if selected:
                sys.setprofile(capture)
            try:
                row = detector.process(scan.points,scan.timestamp_s,scan.point_times,point_attributes=scan.attributes,capture_diagnostics=scan.index in diagnostic_frames.get(name,()))
            finally:
                sys.setprofile(prior_profile)
            row.update(frame=scan.index,measurement_timestamp_ns=scan.measurement_timestamp_ns,record_timestamp_ns=scan.record_timestamp_ns,source_scan_id=f'{scan.topic}:{scan.frame_id}:{scan.measurement_timestamp_ns}')
            expected = json.loads(next(reference))
            changes = [k for k in set(row)|set(expected) if k not in ignored and row.get(k)!=expected.get(k)]
            if changes:
                write_json(out/'identity-failure.json', {'recording':name,'frame':scan.index,'fields':changes,'actual':row,'expected':expected})
                raise ValueError('Scientific identity changed')
            scientific = {k:v for k,v in row.items() if k not in ignored}
            signature = hashlib.sha256(json.dumps(scientific,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
            frames.write(json.dumps({'frame':scan.index,'measurement_timestamp_ns':scan.measurement_timestamp_ns,'scientific_sha256':signature})+'\n')
            counts['frames'] += 1
            if selected:
                if not context:
                    raise ValueError('Missing observed cluster mapping')
                context['cluster_original_return_indices'] = detector.diagnostic_arrays.get('cluster_source_indices')
                records, fitted_model = measure_local(context,row['objects'],selected)
                if {str(r['component_id']) for r in records} != set(selected):
                    raise ValueError('Target component missing')
                for record in records:
                    obj = record['object']
                    if record['certified_queries'] - record['certified_structural_queries'] != obj['certified_unexplained_voxels']:
                        raise ValueError('Point-support mapping mismatch')
                evidence.write(json.dumps({'frame':scan.index,'measurement_timestamp_ns':scan.measurement_timestamp_ns,'geometry':row['geometry'],'fitted_background_model':fitted_model,'records':records},allow_nan=False)+'\n')
                counts['target_frames'] += 1
                counts['target_components'] += len(records)
            if counts['frames'] % 100 == 0:
                print(json.dumps({'recording':name,**counts}),flush=True)
        if next(reference,None) is not None or counts['frames'] != entry['metadata_message_count']:
            raise ValueError('Incomplete recording')
    if counts['target_frames'] != len(targets.get(name,{})):
        raise ValueError('Incomplete target frame selection')
    summaries[name] = {'counts':dict(counts),'scientific_identity':True,'wall_s':time.perf_counter()-started,'reference_sha256':digest(reference_path)}
    write_json(out/'recordings.json',summaries)
    print(json.dumps({'completed':name,**summaries[name]}),flush=True)
write_json(out/'completion.json',{'complete':True,'recordings':summaries})
