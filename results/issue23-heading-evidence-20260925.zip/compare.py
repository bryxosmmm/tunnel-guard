import gzip
import hashlib
import json
from collections import defaultdict
from pathlib import Path
import numpy as np

root=Path('build/issue23-heading-evidence')
plan=json.loads((root/'comparison-plan.json').read_text())
if hashlib.sha256(Path(plan['holdouts']).read_bytes()).hexdigest()!=plan['holdouts_sha256']:
    raise ValueError('Frozen holdouts changed')
with gzip.open(plan['holdouts'],'rt') as stream:
    holdouts={(r['recording'],r['frame']):r for r in map(json.loads,stream)}
with gzip.open(plan['fallback_pairs'],'rt') as stream:
    fallback={(r['recording'],r['frame']):r for r in map(json.loads,stream)}
out=Path(plan['output']);out.mkdir(parents=True,exist_ok=False)
(out/'experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
(out/'compare.py').write_bytes(Path(__file__).read_bytes())
groups=defaultdict(list)
seen=set()
with gzip.open(out/'heading-pairs.jsonl.gz','wt') as journal:
    for source in plan['inputs']:
        name=source['recording'];path=Path(plan['reference_root'])/(name+'.jsonl.gz')
        with path.open('rb') as stream:
            if hashlib.file_digest(stream,'sha256').hexdigest()!=source['sha256']:
                raise ValueError('Saved recording changed')
        count=0
        with gzip.open(path,'rt') as stream:
            for frame,line in enumerate(stream):
                count+=1;key=(name,frame)
                if key not in holdouts: continue
                row=json.loads(line);prior=holdouts[key]
                anchors=row['geometry']['rail_anchors']
                if anchors!=prior['retained_anchors']:
                    raise ValueError('Holdout anchor identity changed')
                diagnostics=row['geometry']['rail_support_diagnostics'][:len(anchors)]
                if len(diagnostics)!=len(anchors) or any(a[0]!=d['x_m'] for a,d in zip(anchors,diagnostics)):
                    raise ValueError('Diagnostic prefix does not match retained anchors')
                heading=diagnostics[-2]['heading_slope']
                distance=anchors[-1][0]-anchors[-2][0]
                predicted=anchors[-2][1]+heading*distance
                pair={'recording':name,'frame':frame,'role':prior['role'],
                    'negative_alarm':prior['negative_alarm'],'training_selected_anchors':prior['training_selected_anchors'],
                    'retained_anchors':anchors,'retained_heading_diagnostics':diagnostics,
                    'original_signed_discrepancy_m':prior['signed_discrepancy_m'],
                    'secant_signed_discrepancy_m':fallback[key]['fallback_signed_discrepancy_m'],
                    'stored_heading_signed_discrepancy_m':predicted-anchors[-1][1],
                    'training_edge_stored_heading':heading,
                    'training_edge_continuation_heading':prior['continuation_coefficients'][2],
                    'heldout_distance_m':distance}
                journal.write(json.dumps(pair,allow_nan=False)+'\n');seen.add(key)
                for group in ['all','selected:'+str(pair['training_selected_anchors']),'recording:'+name]: groups[group].append(pair)
                if pair['negative_alarm']: groups['negative_alarm'].append(pair)
        if count!=source['frames']: raise ValueError('Incomplete recording')
        print(json.dumps({'completed':name,'frames':count}),flush=True)
if seen!=holdouts.keys(): raise ValueError('Incomplete paired observations')
summary={}
for key,rows in groups.items():
    old=np.abs([r['original_signed_discrepancy_m'] for r in rows])
    new=np.abs([r['stored_heading_signed_discrepancy_m'] for r in rows])
    summary[key]={'paired_holdouts':len(rows),'stored_heading_lower_error':int((new<old).sum()),
        'stored_heading_higher_error':int((new>old).sum()),'equal_error':int((new==old).sum()),
        'original_absolute_error_quantiles_m':list(map(float,np.quantile(old,[.5,.9,.99,1]))),
        'stored_heading_absolute_error_quantiles_m':list(map(float,np.quantile(new,[.5,.9,.99,1]))),
        'original_mean_absolute_error_m':float(old.mean()),'stored_heading_mean_absolute_error_m':float(new.mean())}
report={'groups':summary,'quantile_order':['median','p90','p99','max'],'limits':plan['limits'],
        'decision':'Inspect regressions and sampled heading provenance; no detector change or promotion.'}
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
