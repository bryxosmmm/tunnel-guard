"""Observe real assignment and native shape recurrence without changing detector decisions."""
import inspect
import json
from pathlib import Path
import runpy
import sys
import numpy as np
import tunnel_guard.detector as module

plan = json.loads(Path(sys.argv[1]).read_text())
reference = json.loads(Path(plan['attribution_reference']).read_text())
queries = {}
for event in plan['focus_events']:
    previous = []
    for row in reference[str(event)]:
        if plan['focus_start_frame'] <= row['frame'] < plan['max_frames']:
            queries.setdefault(row['frame'], []).append({'event': event,
                'components': [o['component_id'] for o in row['components']], 'previous_tracks': previous})
        if row['components']:
            previous = [o['track_id'] for o in row['components']]
original = module.linear_sum_assignment
stream = Path(plan['assignment_trace']).open('x')

def observed(cost):
    result = original(cost)
    caller = inspect.currentframe().f_back
    try:
        v = caller.f_locals
        detector = v['self']
        frame = detector.frame_number - 1
        if frame not in queries:
            return result
        cfg = detector.config
        radius = cfg['local_confirmation']['shape_radius_m']
        threshold = cfg['local_confirmation']['minimum_symmetric_overlap']
        objects, ids = v['objects'], v['ids']
        columns = {o['component_id']: i for i, o in enumerate(objects)}
        chosen = {int(c): ids[int(r)] for r, c in zip(*result) if c < len(objects) and cost[r, c] < 1e6}
        eligible = {i for i, o in enumerate(objects) if o['path_relation'] == 'intersecting'
                    and o['certified_unexplained_voxels'] >= cfg['claim_min_support_voxels']
                    and len(o['_support_points']) >= cfg['evidence_min_points']}
        consecutive = {key: t for key, t in detector.tracks.items()
                       if t.get('local_frame') == detector.frame_number - 1 and t.get('local_shape') is not None}
        centered = {}
        cache = {}
        def pair(key, column):
            token = (key, column)
            if token in cache:
                return cache[token]
            track = detector.tracks[key]
            previous = track.get('local_shape')
            available = key in consecutive and column in eligible
            info = {'track_id': key, 'component_id': objects[column]['component_id'],
                    'consecutive_previous_shape': key in consecutive, 'current_eligible': column in eligible,
                    'previous_hits': track.get('local_hits', 0), 'symmetric_overlap': None,
                    'passes_existing_shape_gate': False, 'would_reach_existing_hit_gate': False}
            r = ids.index(key)
            info.update(global_allowed=bool(v['allowed'][r,column]),
                        global_cost=float(cost[r,column]), mahalanobis=float(v['mahalanobis'][r,column]),
                        extent_log_difference=float(v['shape'][r,column]),
                        selected_by_global_assignment=chosen.get(column)==key)
            if available:
                if column not in centered:
                    centered[column] = objects[column]['_support_points'] - v['centers'][column]
                current = centered[column]
                forward = module.accelerator.keep_outside_radius(current, previous, radius, detector.native_kernels)
                backward = module.accelerator.keep_outside_radius(previous, current, radius, detector.native_kernels)
                overlap = min(1.0-float(forward.mean()), 1.0-float(backward.mean()))
                passes = overlap >= threshold
                info.update(symmetric_overlap=overlap, passes_existing_shape_gate=passes,
                    previous_points=len(previous), current_points=len(current),
                    would_reach_existing_hit_gate=passes and track.get('local_hits',0)+1 >= cfg['confirmation_hits'])
            cache[token] = info
            return info
        for query in queries[frame]:
            targets = [columns[c] for c in query['components'] if c in columns]
            target_records = []
            for column in targets:
                relevant = set(consecutive) | {k for k in query['previous_tracks'] if k in detector.tracks}
                if column in chosen:
                    relevant.add(chosen[column])
                matches = [pair(key,column) for key in sorted(relevant)]
                target_records.append({'component_id': objects[column]['component_id'],
                    'assigned_track': chosen.get(column), 'current_eligible': column in eligible,
                    'passing_track_ids': [m['track_id'] for m in matches if m['passes_existing_shape_gate']],
                    'pairs': matches})
            previous_records = []
            for key in query['previous_tracks']:
                if key not in detector.tracks:
                    previous_records.append({'track_id':key,'retained':False})
                    continue
                matches = [pair(key,j) for j in sorted(eligible)]
                previous_records.append({'track_id':key,'retained':True,
                    'passing_component_ids':[m['component_id'] for m in matches if m['passes_existing_shape_gate']],
                    'pairs':matches})
            stream.write(json.dumps({'frame':frame,'event':query['event'],
                'motion_valid':bool(v['motion']['valid']), 'shape_radius_m':radius,
                'minimum_symmetric_overlap':threshold, 'eligible_current_components':len(eligible),
                'consecutive_previous_shapes':len(consecutive), 'targets':target_records,
                'previous_event_tracks':previous_records},allow_nan=False)+'\n')
        stream.flush()
        return result
    finally:
        del caller

module.linear_sum_assignment = observed
try:
    runpy.run_path(plan['replay_runner'],run_name='__main__')
finally:
    module.linear_sum_assignment = original
    stream.close()
