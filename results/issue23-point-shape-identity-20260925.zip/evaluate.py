"""Evaluate actual replay invariance and observed alternative shape matches."""
import gzip
import json
from collections import Counter
from pathlib import Path
import sys

root = Path(sys.argv[1])
plan = json.loads((root/'experiment.json').read_text())
reference = json.loads(Path(plan['attribution_reference']).read_text())
prior_frames = {}
for event in plan['focus_events']:
    last = None
    for row in reference[str(event)]:
        prior_frames[event,row['frame']] = last
        if row['components']:
            last = row['frame']
reference_rows = Path(plan['attribution_reference']).with_name('cloud_with_fake_obj.jsonl.gz')
ignored = ['processing_s','motion_s','mounting_observation_s']
changed = []
count = 0
with gzip.open(reference_rows,'rt') as baseline, gzip.open(Path(plan['output'])/'cloud_with_fake_obj.jsonl.gz','rt') as replay:
    for count, line in enumerate(replay,1):
        actual, expected = json.loads(line), json.loads(next(baseline))
        differences = [key for key in set(actual)|set(expected) if key not in ignored and actual.get(key)!=expected.get(key)]
        if differences:
            changed.append({'frame':actual['frame'],'fields':differences})
identity = {'frames':count,'expected_frames':plan['max_frames'],'ignored_elapsed_fields':ignored,
            'changed_scientific_frames':changed,'valid':count==plan['max_frames'] and not changed}
rows = [json.loads(line) for line in (root/'pairs.jsonl').read_text().splitlines()]
counts = {event:Counter() for event in plan['focus_events']}
findings = []
for row in rows:
    event, frame = row['event'],row['frame']
    counter = counts[event]
    counter['observed_event_frames'] += 1
    if not row['targets']:
        counter['no_attributed_target_component_frames'] += 1
    previous = {p['track_id']:p for p in row['previous_event_tracks']}
    immediate_attribution = prior_frames[event,frame] == frame-1
    for target in row['targets']:
        counter['target_components'] += 1
        if not target['current_eligible']:
            counter['current_ineligible_components'] += 1
            continue
        counter['current_eligible_components'] += 1
        pairs = target['pairs']
        selected = next((p for p in pairs if p['selected_by_global_assignment']),None)
        selected_passes = bool(selected and selected['passes_existing_shape_gate'])
        passing = target['passing_track_ids']
        counter['eligible_with_'+('zero' if not passing else 'one' if len(passing)==1 else 'multiple')+'_shape_matches'] += 1
        if selected_passes:
            counter['selected_identity_passes_shape'] += 1
        alternative = [p for p in pairs if p['track_id'] in previous and p['passes_existing_shape_gate']
                       and not p['selected_by_global_assignment']]
        for p in alternative:
            reverse = previous[p['track_id']]['passing_component_ids']
            mutual_unique = len(passing)==1 and reverse==[target['component_id']]
            item = {'frame':frame,'event':event,'component_id':target['component_id'],
                    'previous_event_track':p['track_id'],'previous_attributed_frame':prior_frames[event,frame],
                    'immediately_previous_attribution':immediate_attribution,
                    'selected_track':target['assigned_track'],'selected_passes_shape':selected_passes,
                    'selected_overlap':selected['symmetric_overlap'] if selected else None,
                    'prior_pair':p,'all_passing_previous_tracks':passing,
                    'all_current_components_matching_prior_track':reverse,
                    'mutually_unique_shape_match':mutual_unique,'motion_valid':row['motion_valid']}
            findings.append(item)
            counter['alternative_prior_event_shape_matches'] += 1
            if immediate_attribution and not selected_passes:
                counter['immediate_prior_passes_selected_fails_pairs'] += 1
                counter['immediate_prior_'+('mutually_unique' if mutual_unique else 'ambiguous')+'_pairs'] += 1
                counter['immediate_prior_global_'+('allowed' if p['global_allowed'] else 'rejected')+'_pairs'] += 1
report = {'hypothesis':plan['hypothesis'],'criterion':plan['criterion'],'identity':identity,
          'events':{str(e):dict(c) for e,c in counts.items()},'alternative_prior_matches':findings,
          'examples': [r for r in rows if r['frame'] in [714,742,793,797,798]],
          'limits':['Forensic inserted-return attribution is an evaluation label, not a detector input or field-recall denominator.',
                    'Shape matching uses the unchanged 0.1m radius and 0.8 symmetric overlap; translation centering removes identity information.',
                    'A shape match alone does not establish physical identity or safe temporal confirmation.',
                    'No association modification, negative-panel replay, primary-metric measurement or promotion is performed.',
                    'Previous event track may have stale attribution; immediate-attribution cases are reported separately.',
                    'Counters are component/pair counts, not independent events.']}
(root/'evaluation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'identity':identity,'events':report['events'],'alternative_pairs':len(findings)},indent=2))
if not identity['valid']:
    raise SystemExit('Scientific replay identity failed')
