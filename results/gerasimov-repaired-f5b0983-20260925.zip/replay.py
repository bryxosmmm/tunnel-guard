"""Actual continuous detector replay with frozen original-return attribution; not generated inputs."""
from collections import Counter, defaultdict
import gzip
import io
import json
import os
from pathlib import Path
import shutil
import sys
import time
import zipfile
import numpy as np
from tunnel_guard import _native
from tunnel_guard.detector import Detector, load_config
from tunnel_guard.io import iter_bag
from tunnel_guard.run import capture_native_sources, digest, environment, write_json

plan = json.loads(Path(sys.argv[1]).read_text())
config = load_config(plan['detector_config'])
if config['seed'] != plan['seed'] or any(os.environ.get(k) != v for k, v in plan['thread_environment'].items()):
    raise ValueError('Recipe seed or thread environment mismatch')
out = Path(plan['output'])
out.mkdir(parents=True, exist_ok=False)
write_json(out / 'experiment.json', plan)
write_json(out / 'detector.json', config)
source = Path(_native.__file__).parent
shutil.copytree(source, out / 'source/tunnel_guard', ignore=shutil.ignore_patterns('__pycache__', '*.so'))
shutil.copyfile(__file__, out / 'replay.py')
capture_native_sources(out / 'source')
write_json(out / 'manifest.json', environment() | {
    'base_commit': plan['base_commit'], 'repair_commit': plan['repair_commit'],
    'source_path': str(source), 'native_path': str(_native.__file__),
    'native_sha256': digest(Path(_native.__file__)), 'config_sha256': digest(Path(plan['detector_config'])),
    'recipe_sha256': digest(Path(sys.argv[1])), 'archive_sha256': digest(Path(plan['source_archive'])),
    'source_hashes': {str(p.relative_to(out / 'source')): digest(p) for p in (out / 'source').rglob('*') if p.is_file()}})
with zipfile.ZipFile(plan['source_archive']) as archive:
    prefix = plan['source_prefix']
    observations = json.loads(archive.read(prefix + 'input-observations.json'))
    tracks = json.loads(archive.read(prefix + 'source-track-map.json'))
    with np.load(io.BytesIO(archive.read(prefix + 'inferred-suffix-support.npz'))) as data:
        offsets = data['offsets'].copy()
by_frame = defaultdict(list)
for event, track in enumerate(tracks, 1):
    for frame, cluster in track:
        by_frame[frame].append((event, cluster))
bag = Path(plan['bag'])
if digest(bag / 'metadata.yaml') != plan['bag_metadata_sha256']:
    raise ValueError('Changed bag metadata')
detector = Detector(config)
records = defaultdict(list)
counts = Counter()
seen = set()
count = 0
started = time.perf_counter()
with gzip.open(out / 'cloud_with_fake_obj.jsonl.gz', 'wt', compresslevel=1) as stream:
    for scan in iter_bag(bag, config, every=1, max_frames=plan['max_frames']):
        reference = observations[scan.index]
        if (scan.index != count or scan.measurement_timestamp_ns in seen
                or scan.measurement_timestamp_ns != reference['stamp_ns']
                or scan.record_timestamp_ns != reference['recorded_ns'] or scan.raw_points != reference['raw_n']):
            raise ValueError('Acquisition identity mismatch')
        seen.add(scan.measurement_timestamp_ns)
        row = detector.process(scan.points, scan.timestamp_s, scan.point_times,
            capture_diagnostics=scan.index in by_frame, point_attributes=scan.attributes)
        row.update(frame=scan.index, measurement_timestamp_ns=scan.measurement_timestamp_ns,
                   record_timestamp_ns=scan.record_timestamp_ns,
                   source_scan_id=f'{scan.topic}:{scan.frame_id}:{scan.measurement_timestamp_ns}')
        stream.write(json.dumps(row, allow_nan=False) + '\n')
        arrays = detector.diagnostic_arrays
        for event, j in by_frame[scan.index]:
            cluster = reference['clusters'][j]
            ids = reference['suffix_start'] + np.asarray(cluster['point_indices']) - offsets[scan.index]
            member = np.isin(arrays.get('cluster_source_indices', np.array([], dtype=int)), ids)
            labels = arrays.get('cluster_labels', np.array([], dtype=int))
            attributed = []
            for obj in row['objects']:
                selected = labels == obj['component_id']
                total = int(selected.sum())
                matched = int(np.count_nonzero(member & selected))
                if matched and matched / total >= plan['minimum_inserted_fraction_for_attribution']:
                    attributed.append(obj)
            records[event].append({'frame': scan.index, 'stamp_ns': scan.measurement_timestamp_ns,
                'source_forward_m': cluster['center'][0], 'components': attributed})
        count += 1
        counts[row['status']] += 1
        if count % 100 == 0:
            stream.flush()
            print(f'{count}/{plan["max_frames"]}: {row["status"]}', flush=True)
if count != plan['max_frames']:
    raise ValueError('Incomplete configured recording')
write_json(out / 'synthetic.json', dict(records))
summary = {'frames': count, 'status_frames': dict(counts), 'wall_s': time.perf_counter() - started}
write_json(out / 'summary.json', summary)
print(json.dumps(summary), flush=True)
