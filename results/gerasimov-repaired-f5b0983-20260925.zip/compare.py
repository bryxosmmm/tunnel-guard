"""Separate evaluation of completed actual replays against retained best evidence."""
from collections import Counter
import gzip
import itertools
import json
from pathlib import Path
import sys

plan = json.loads(Path(sys.argv[1]).read_text())
candidate = Path(plan['candidate'])
best = Path(plan['best'])
changed = {k: [] for k in ('status', 'geometry', 'pose', 'motion', 'supported_range_m',
                          'range_observability', 'unresolved_range_objects', 'nearest_unresolved_range_m')}
geometry_keys = ('component_id', 'bbox_min', 'bbox_max', 'center', 'extent_m')
object_geometry_changes = []
valid_geometry_changes = []
unknown_as_clear = []
counts = {'candidate': Counter(), 'best': Counter()}
missing_geometry = []
row_count = 0
with gzip.open(candidate / 'cloud_with_fake_obj.jsonl.gz', 'rt') as a, gzip.open(best / 'cloud_with_fake_obj.jsonl.gz', 'rt') as b:
    for index, pair in enumerate(itertools.zip_longest(a, b)):
        if None in pair:
            raise ValueError('Paired replay lengths differ')
        left, right = map(json.loads, pair)
        for key in ('frame', 'source_scan_id', 'measurement_timestamp_ns', 'record_timestamp_ns'):
            if left[key] != right[key]:
                raise ValueError(f'Acquisition mismatch at{index}: {key}')
        row_count += 1
        counts['candidate'][left['status']] += 1
        counts['best'][right['status']] += 1
        for key in changed:
            if left.get(key) != right.get(key):
                changed[key].append(index)
                if key == 'geometry' and right['geometry'].get('valid'):
                    valid_geometry_changes.append(index)
        if [{k: obj.get(k) for k in geometry_keys} for obj in left['objects']] != [
                {k: obj.get(k) for k in geometry_keys} for obj in right['objects']]:
            object_geometry_changes.append(index)
        if right['status'] == 'unknown' and left['status'] == 'no_obstacle_observed':
            unknown_as_clear.append(index)
        if not left.get('geometry', {}).get('valid', False):
            missing_geometry.append({k: left.get(k) for k in ('frame', 'status', 'reason', 'supported_range_m')})
        if index == plan['historical_failure_frame']:
            repaired_failure = {k: left.get(k) for k in ('frame', 'status', 'reason', 'supported_range_m', 'geometry')}
if row_count != plan['expected_frames']:
    raise ValueError('Incomplete expected corpus')
a_events = json.loads((candidate / 'synthetic.json').read_text())
b_events = json.loads((best / 'synthetic.json').read_text())

def confirmed(rows, key):
    return {r['frame'] for r in rows if any(o.get(key, False) for o in r['components'])}

def continuity(frames):
    longest = current = 0
    previous = None
    for frame in sorted(frames):
        current = current + 1 if previous is not None and frame == previous + 1 else 1
        longest = max(longest, current)
        previous = frame
    return longest

events = {}
for event, expected in b_events.items():
    actual = a_events[event]
    if [(r['frame'], r['stamp_ns'], r['source_forward_m']) for r in actual] != [
            (r['frame'], r['stamp_ns'], r['source_forward_m']) for r in expected]:
        raise ValueError('Different frozen event acquisitions')
    event_result = {'contour_disagreement_not_clean_negative': int(event) in (5, 7)}
    for key in ('presence_confirmed', 'intersection_confirmed'):
        actual_frames, expected_frames = confirmed(actual, key), confirmed(expected, key)
        first = next((r for r in actual if r['frame'] in actual_frames), None)
        event_result[key] = {'candidate_frames': len(actual_frames), 'best_frames': len(expected_frames),
            'lost_best_frames': sorted(expected_frames - actual_frames),
            'gained_frames': sorted(actual_frames - expected_frames),
            'candidate_longest_consecutive': continuity(actual_frames),
            'best_longest_consecutive': continuity(expected_frames),
            'candidate_first_forward_m': first['source_forward_m'] if first else None}
    events[event] = event_result
lost_positive = any(events[str(event)][key]['lost_best_frames']
    for event in plan['positive_events'] for key in ('presence_confirmed', 'intersection_confirmed'))
result = {'frames': row_count, 'status_counts': {k: dict(v) for k, v in counts.items()},
    'changed_frames': changed, 'valid_geometry_changed_frames': valid_geometry_changes,
    'object_geometry_changed_frames': object_geometry_changes, 'unknown_as_clear_frames': unknown_as_clear,
    'missing_geometry_frames': missing_geometry, 'historical_failure_frame_after_repair': repaired_failure,
    'events': events, 'retains_every_best_positive_frame': not lost_positive,
    'limits': ['Recorded best run reused, not rerun. Timing is not a controlled speed comparison.',
               'Organizer synthetic attribution is not field recall; events5/7 retain contour disagreement.']}
Path(plan['output']).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'frames':row_count,'retains_every_best_positive_frame':not lost_positive,
    'changed_frame_counts':{k:len(v) for k,v in changed.items()},
    'intersection_counts':{e:[r['intersection_confirmed']['candidate_frames'],r['intersection_confirmed']['best_frames']] for e,r in events.items()}},indent=2))
