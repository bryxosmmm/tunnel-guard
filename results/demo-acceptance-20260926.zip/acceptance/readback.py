import json
from collections import Counter
from pathlib import Path
from rosbags.rosbag2 import Reader
from rosbags.typesys import Stores, get_typestore

store = get_typestore(Stores.ROS2_HUMBLE)
reports = []
for folder, bag in [('demo-person-20260926', 'doubleT_obstacle'), ('demo-platform-20260926', 'doubleT_platform')]:
    root = Path('build') / folder
    rows = {r['measurement_timestamp_ns']: r for r in map(json.loads, (root / f'{bag}.jsonl').open())}
    counts = Counter()
    errors = []
    with Reader(root / f'{bag}_rviz') as reader:
        topics = {c.topic: c.msgtype for c in reader.connections}
        for connection, stamp, raw in reader.messages():
            message = store.deserialize_cdr(raw, connection.msgtype)
            counts[connection.topic] += 1
            if stamp not in rows:
                errors.append({'stamp': stamp, 'reason': 'unknown acquisition'})
                continue
            if connection.topic == '/perception/status':
                saved = json.loads(message.data)
                row = rows[stamp]
                differences = [key for key in row if key != 'visualization_s' and saved.get(key) != row[key]]
                extra = set(saved) - set(row)
                if extra != {'presentation', 'display_points', 'distance_summary'}:
                    errors.append({'stamp': stamp, 'reason': 'unexpected presentation schema', 'fields': sorted(extra)})
                if saved.get('presentation') != 'recorded_result_replay' or not 0 <= saved.get('display_points', -1) <= 10000:
                    errors.append({'stamp': stamp, 'reason': 'invalid replay presentation metadata'})
                if differences:
                    errors.append({'stamp': stamp, 'fields': differences})
            elif connection.topic == '/perception/points_display':
                if message.header.frame_id != 'tunnel_guard_local' or message.width > 10000:
                    errors.append({'stamp': stamp, 'reason': 'cloud frame or display bound'})
            elif connection.topic == '/perception/debug_markers':
                if not message.markers or message.markers[0].action != 3:
                    errors.append({'stamp': stamp, 'reason': 'missing initial DELETEALL'})
        reports.append({'recording': bag, 'frames': len(rows), 'topics': topics, 'counts': dict(counts), 'all_topics_one_message_per_acquisition': all(n == len(rows) for n in counts.values()), 'errors': errors})
Path('build/demo-acceptance-20260926/ros-readback.json').write_text(json.dumps(reports, indent=2) + '\n')
print(json.dumps(reports, indent=2))
