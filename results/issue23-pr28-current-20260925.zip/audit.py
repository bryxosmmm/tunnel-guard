"""Separate component-level qualification of the actual completed surface candidate."""
import json
from pathlib import Path
import sys
root = Path(sys.argv[1])
plan = json.loads((root/'comparison.json').read_text())
best = json.loads((Path(plan['best'])/'synthetic.json').read_text())
candidate = json.loads((Path(plan['candidate'])/'synthetic.json').read_text())
comparison = json.loads(Path(plan['output']).read_text())
losses = []; missing = []; localization = []; new_breaks = []
geometry_keys = ['bbox_min','bbox_max','center','extent_m','component_id']
for event, expected_rows in best.items():
    actual_rows = candidate[event]
    if [(r['frame'],r['stamp_ns']) for r in actual_rows] != [(r['frame'],r['stamp_ns']) for r in expected_rows]:
        raise ValueError('Event acquisition mismatch')
    previous = {}
    previous_frame = None
    for expected, actual in zip(expected_rows, actual_rows):
        frame = expected['frame']
        actual_objects = {o['component_id']:o for o in actual['components']}
        current = {}
        for obj in expected['components']:
            after = actual_objects.get(obj['component_id'])
            address = {'event':event,'frame':frame,'component_id':obj['component_id']}
            if after is None:
                missing.append(address | {'before':obj})
            elif any(obj.get(k)!=after.get(k) for k in geometry_keys):
                localization.append(address | {'before':{k:obj.get(k) for k in geometry_keys},'after':{k:after.get(k) for k in geometry_keys}})
            lost = [k for k in ['presence_confirmed','intersection_confirmed'] if obj.get(k) and not (after and after.get(k))]
            if lost:
                losses.append(address | {'lost':lost,'before':obj,'after':after})
            if after is not None and obj['presence_confirmed']:
                current[obj['track_id']] = after['track_id']
                if previous_frame == frame-1 and obj['track_id'] in previous and previous[obj['track_id']] != after['track_id']:
                    new_breaks.append(address | {'baseline_track_id':obj['track_id'],'candidate_before':previous[obj['track_id']],'candidate_after':after['track_id']})
        previous, previous_frame = current, frame
invariant_changes = {k:v for k,v in comparison['changed_frames'].items() if k in ['geometry','pose','motion','supported_range_m','range_observability','unresolved_range_objects','nearest_unresolved_range_m'] and v}
accepted = not (losses or missing or localization or new_breaks or invariant_changes or comparison['unknown_as_clear_frames'])
report = {'complete':comparison['frames']==1510,'positive_component_gate_passed':accepted,
          'lost_confirmations':losses,'missing_positive_components':missing,'positive_localization_changes':localization,
          'induced_positive_track_breaks':new_breaks,'invariant_changes':invariant_changes,
          'retains_every_best_positive_frame':comparison['retains_every_best_positive_frame'],
          'range_unresolved_changed_frames':comparison['changed_frames']['unresolved_range_objects'],
          'decision':('Positive component gate passed; person, edge/long-object and fixed negative acceptance still required.' if accepted else 'Reject this rebased PR28 candidate before costly negative replay; retain best core/config.'),
          'limits':['Original component IDs identify unchanged clustering, not independently labelled physical object identities.',
                    'Track-break counter only covers consecutive baseline-present component correspondences.',
                    'Events5/7 preserve contour disagreement; all regressions are still reported, not silently excluded.',
                    'No new field-safety or negative nuisance reduction claim.']}
(root/'positive-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'complete':report['complete'],'positive_component_gate_passed':accepted,'lost_component_confirmations':len(losses),'missing_positive_components':len(missing),'positive_localization_changes':len(localization),'induced_positive_track_breaks':len(new_breaks),'invariant_changes':{k:len(v) for k,v in invariant_changes.items()},'decision':report['decision']},indent=2))
