"""Actual unchanged replay; measure whether projected structure has local outward support."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
from collections import Counter
import numpy as np
import tunnel_guard.detector as module
from tunnel_guard.geometry import CrossSection, TrackGeometry
from tunnel_guard.io import iter_bag
from tunnel_guard import _native
from tunnel_guard.run import capture_native_sources, environment, digest, write_json

plan = json.loads(Path(sys.argv[1]).read_text())
config = module.load_config(plan['detector_config'])
if digest(Path(plan['detector_config'])) != plan['config_sha256']:
    raise ValueError('Configuration changed')
if config['seed'] != plan['seed'] or any(os.environ.get(k) != v for k,v in plan['thread_environment'].items()):
    raise ValueError('Seed/thread environment changed')
for name, expected in plan['source_sha256'].items():
    if digest(Path(name)) != expected:
        raise ValueError('Source changed: '+name)
if digest(Path(_native.__file__)) != plan['native_sha256']:
    raise ValueError('Native binary changed')
out = Path(plan['output'])
out.mkdir(parents=True, exist_ok=False)
write_json(out/'experiment.json', plan)
write_json(out/'detector.json', config)
shutil.copytree('tunnel_guard', out/'source/tunnel_guard', ignore=shutil.ignore_patterns('*.so','__pycache__','.DS_Store'))
capture_native_sources(out/'source')
shutil.copy2(__file__, out/'replay.py')
write_json(out/'manifest.json', environment() | {'command':sys.argv, 'native_sha256':digest(Path(_native.__file__)), 'config_sha256':plan['config_sha256'], 'source_sha256':plan['source_sha256']})
ignored = set(plan['ignored_elapsed_fields'])
targets = json.loads(Path(plan['targets']).read_text())
if digest(Path(plan['targets'])) != plan['targets_sha256']:
    raise ValueError('Target inventory changed')
cluster_code = module.cluster_candidates.__code__
structure_code = TrackGeometry.structural_mask.__code__
diagnostic_frames = {name:set(frames) for name,frames in plan.get('diagnostic_frames',{}).items()}


def measure_local(context, objects, target_ids):
    points, section, geometry = context['points'], context['section'], context['geometry']
    cloud_rows, labels, core = context['cluster_rows'], context['labels'], context['core']
    if cloud_rows is None:
        if not module.voxel_unique_at(config, context['reduced_on_grid_m']):
            raise ValueError('Unexpected missing native cluster selection')
        cloud_rows = np.flatnonzero(context['context'])
    if not np.array_equal(points[cloud_rows], context['cloud']):
        raise ValueError('Observed cluster mapping differs from actual selected points')
    structural = context['structural']
    stations = np.floor(points[:,0]/config['structure_station_m']).astype(np.int64)
    coarse = config['structure_support_cell_m']
    # Observe the currently effective second grid, not the rejected union-grid proposal.
    cells = np.column_stack((np.floor((section.lateral+coarse/2)/coarse), np.floor((section.running_height+coarse/2)/coarse))).astype(np.int64)
    local_outward = {}
    records = []
    for obj in objects:
        cid = obj['component_id']
        if str(cid) not in target_ids:
            continue
        member = labels == cid
        query = np.flatnonzero(member & core)
        global_rows = cloud_rows[query]
        local_flags = []
        for station in np.unique(stations[global_rows]):
            station = int(station)
            if station not in local_outward:
                selected = np.flatnonzero(stations == station)
                observed = {}
                def capture(frame, event, arg):
                    if event == 'return' and frame.f_code is structure_code:
                        values = frame.f_locals
                        observed['outward'] = values['outward'][values['column']-values['column_min'], values['row']-values['row_min']+1].copy()
                prior_profile = sys.getprofile()
                sys.setprofile(capture)
                try:
                    # Execute the existing implementation on one occupied station. Its
                    # longitudinal support verdict is deliberately NOT used as a candidate.
                    geometry.structural_mask(points[selected], CrossSection(section.lateral[selected], section.running_height[selected], section.gauge[selected]))
                finally:
                    sys.setprofile(prior_profile)
                local_outward[station] = (selected, observed['outward'])
            selected, outward = local_outward[station]
            chosen = global_rows[stations[global_rows] == station]
            local_flags.extend(outward[np.searchsorted(selected, chosen)].tolist())
        member_full = np.zeros(len(points), dtype=bool)
        member_full[cloud_rows[member]] = True
        external_dx = []
        cell_records = []
        for cell in np.unique(cells[global_rows], axis=0):
            same = np.all(cells == cell, axis=1)
            external = np.flatnonzero(same & ~member_full)
            selected_query = global_rows[np.all(cells[global_rows] == cell, axis=1)]
            if len(external):
                xs = np.sort(points[external,0])
                query_x = points[selected_query,0]
                ix = np.searchsorted(xs, query_x)
                distance = np.minimum(np.abs(xs[np.minimum(ix,len(xs)-1)]-query_x), np.abs(xs[np.maximum(ix-1,0)]-query_x))
                external_dx.extend(distance.tolist())
            cell_records.append({'cell':cell.tolist(), 'certified_queries':len(selected_query),
                'external_returns':len(external), 'external_stations':len(np.unique(stations[external])),
                'external_x_range_m':[float(points[external,0].min()),float(points[external,0].max())] if len(external) else None})
        records.append({'component_id':cid, 'attribution':target_ids[str(cid)], 'object':obj,
            'certified_queries':len(query), 'certified_structural_queries':int(structural[query].sum()),
            'same_station_outward_queries':sum(local_flags),
            'all_certified_queries_locally_outward':bool(len(query) and all(local_flags)),
            'nearest_external_same_coarse_cell_dx_m':external_dx, 'coarse_cells':cell_records})
    return records

summaries = {}
for entry in plan['recordings']:
    bag = Path(entry['path']); name = bag.name
    if digest(bag/'metadata.yaml') != entry['metadata_sha256']:
        raise ValueError('Bag metadata changed: '+name)
    for file in entry.get('files',entry.get('segments',[])):
        if (bag/file.get('name',file.get('file'))).stat().st_size != file['bytes']:
            raise ValueError('Bag file size changed: '+name)
    detector = module.Detector(config)
    counts = Counter(); started = time.perf_counter(); prior_stamp = None
    reference_path = Path(plan['reference'])/(name+'.jsonl.gz')
    with gzip.open(reference_path,'rt') as reference, gzip.open(out/(name+'-frames.jsonl.gz'),'wt') as frames, gzip.open(out/(name+'-support.jsonl.gz'),'wt') as evidence:
        for scan in iter_bag(bag, config, every=1, max_frames=None):
            if scan.index != counts['frames'] or (prior_stamp is not None and scan.measurement_timestamp_ns <= prior_stamp):
                raise ValueError('Missing/reordered acquisition')
            prior_stamp = scan.measurement_timestamp_ns
            selected = targets.get(name,{}).get(str(scan.index),{})
            context = {}
            def capture(frame,event,arg):
                if event == 'return' and frame.f_code is cluster_code:
                    context.update(frame.f_locals)
            prior_profile = sys.getprofile()
            if selected:
                sys.setprofile(capture)
            try:
                row = detector.process(scan.points,scan.timestamp_s,scan.point_times,point_attributes=scan.attributes,capture_diagnostics=scan.index in diagnostic_frames.get(name,()))
            finally:
                sys.setprofile(prior_profile)
            row.update(frame=scan.index,measurement_timestamp_ns=scan.measurement_timestamp_ns,record_timestamp_ns=scan.record_timestamp_ns,source_scan_id=f'{scan.topic}:{scan.frame_id}:{scan.measurement_timestamp_ns}')
            expected = json.loads(next(reference))
            changes = [k for k in set(row)|set(expected) if k not in ignored and row.get(k)!=expected.get(k)]
            if changes:
                write_json(out/'identity-failure.json', {'recording':name,'frame':scan.index,'fields':changes,'actual':row,'expected':expected})
                raise ValueError('Scientific identity changed')
            scientific = {k:v for k,v in row.items() if k not in ignored}
            signature = hashlib.sha256(json.dumps(scientific,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
            frames.write(json.dumps({'frame':scan.index,'measurement_timestamp_ns':scan.measurement_timestamp_ns,'scientific_sha256':signature})+'\n')
            counts['frames'] += 1
            if selected:
                if not context:
                    raise ValueError('Missing observed cluster mapping')
                records = measure_local(context,row['objects'],selected)
                if {str(r['component_id']) for r in records} != set(selected):
                    raise ValueError('Target component missing')
                for record in records:
                    obj = record['object']
                    if record['certified_queries'] - record['certified_structural_queries'] != obj['certified_unexplained_voxels']:
                        raise ValueError('Point-support mapping mismatch')
                evidence.write(json.dumps({'frame':scan.index,'measurement_timestamp_ns':scan.measurement_timestamp_ns,'geometry':row['geometry'],'records':records},allow_nan=False)+'\n')
                counts['target_frames'] += 1
                counts['target_components'] += len(records)
            if counts['frames'] % 100 == 0:
                print(json.dumps({'recording':name,**counts}),flush=True)
        if next(reference,None) is not None or counts['frames'] != entry['metadata_message_count']:
            raise ValueError('Incomplete recording')
    if counts['target_frames'] != len(targets.get(name,{})):
        raise ValueError('Incomplete target frame selection')
    summaries[name] = {'counts':dict(counts),'scientific_identity':True,'wall_s':time.perf_counter()-started,'reference_sha256':digest(reference_path)}
    write_json(out/'recordings.json',summaries)
    print(json.dumps({'completed':name,**summaries[name]}),flush=True)
write_json(out/'completion.json',{'complete':True,'recordings':summaries})
