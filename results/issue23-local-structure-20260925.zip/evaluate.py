"""Evaluate observed geometry; not a modified-detector benchmark."""
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import sys
root = Path(sys.argv[1])
outputs = sys.argv[2:]
targets = json.loads((root/'targets.json').read_text())
counts = defaultdict(Counter)
exposures = []
recordings = {}
for output in outputs:
    folder = root/output
    completion = json.loads((folder/'completion.json').read_text())
    if not completion['complete']:
        raise ValueError('Incomplete recording stage')
    for name, summary in completion['recordings'].items():
        if name in recordings or not summary['scientific_identity']:
            raise ValueError('Duplicate recording or failed identity')
        recordings[name] = summary
        seen = set()
        with gzip.open(folder/(name+'-support.jsonl.gz'),'rt') as stream:
            for line in stream:
                item = json.loads(line)
                if item['frame'] in seen:
                    raise ValueError('Duplicate observed frame')
                seen.add(item['frame'])
                expected = targets.get(name,{}).get(str(item['frame']),{})
                if {str(r['component_id']):r['attribution'] for r in item['records']} != expected:
                    raise ValueError('Incomplete observed attribution')
                groups = defaultdict(list)
                for record in item['records']:
                    obj = record['object']
                    shared = obj['certified_unexplained_voxels'] == 0
                    local = record['all_certified_queries_locally_outward']
                    exposed = shared and local
                    for role in record['attribution']:
                        group = counts[role]
                        group['confirmed_components'] += 1
                        group['shared_structure_components'] += shared
                        group['all_certified_queries_locally_outward_components'] += local
                        group['shared_and_locally_outward_components'] += exposed
                        group['certified_queries'] += record['certified_queries']
                        group['same_station_outward_queries'] += record['same_station_outward_queries']
                        groups[role].append(exposed)
                for role, flags in groups.items():
                    counts[role]['confirmed_frames'] += 1
                    if all(flags):
                        counts[role]['all_confirmed_components_exposed_frames'] += 1
                        exposures.append({'recording':name,'frame':item['frame'],'role':role,'component_ids':[r['component_id'] for r in item['records'] if role in r['attribution']]})
        if seen != {int(f) for f in targets.get(name,{})}:
            raise ValueError('Missing target frames')
        with gzip.open(folder/(name+'-frames.jsonl.gz'),'rt') as stream:
            trace_count = sum(1 for line in stream)
        if trace_count != summary['counts']['frames']:
            raise ValueError('Missing per-frame identity evidence')
positive_loss = [e for e in exposures if e['role'].startswith('synthetic_event_')]
report = {'valid':True,'recordings':recordings,'counts':{k:dict(v) for k,v in counts.items()},
          'exposed_frames':exposures,'positive_event_frames_exposed':len(positive_loss),
          'decision':('Positive recording not evaluated yet; no positive qualification claim.' if 'cloud_with_fake_obj' not in recordings else 'Reject shared-and-local-outward suppression: it would erase retained positive event-frame intersections.' if positive_loss else 'No observed positive loss under this descriptive predicate; not production acceptance. Remaining negative measurements and actual modified-candidate gates would still be required.'),
          'limitations':['No detector decisions changed. Counterfactual component removal is exposure accounting, not an actual candidate replay.',
                        'Station membership is one-meter quantization, not a proof of connected physical surface.',
                        'Native outward algorithm uses morphological gap allowance; outward occupancy does not establish object identity.',
                        'No absent local support is reclassified as clear or as proven isolation.',
                        'Observed synthetic event-frames are correlated and not field safety evidence.']}
path = root/('evaluation-'+'-'.join(outputs)+'.json')
path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'valid':True,'processed_frames':sum(s['counts']['frames'] for s in recordings.values()),'counts':report['counts'],'positive_event_frames_exposed':len(positive_loss),'decision':report['decision']},indent=2))
